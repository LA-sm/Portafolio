package com.appcrud.adapters

import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.appcrud.R

class TransaccionesAdapter(
    private val transacciones: List<Triple<String, String, Double>>
) : RecyclerView.Adapter<TransaccionesAdapter.TransaccionViewHolder>() {

    inner class TransaccionViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val texto = view.findViewById<TextView>(R.id.tvTransaccion)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransaccionViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_transaccion, parent, false)
        return TransaccionViewHolder(view)
    }

    override fun onBindViewHolder(holder: TransaccionViewHolder, position: Int) {
        val (deudor, acreedor, monto) = transacciones[position]
        val textoCompleto = "$deudor le debe ${"%.2f".format(monto)} € a $acreedor"

        val spannable = SpannableStringBuilder(textoCompleto)

        // Aplicar negrita al nombre del deudor
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            0,
            deudor.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        // "le debe" no lleva estilo (queda como está)

        // Aplicar negrita al monto
        val startMonto = textoCompleto.indexOf('€')
        val endMonto = textoCompleto.indexOf(" a ")
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            startMonto,
            endMonto,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        // Aplicar negrita al nombre del acreedor
        val startAcreedor = textoCompleto.lastIndexOf(acreedor)
        val endAcreedor = textoCompleto.length
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            startAcreedor,
            endAcreedor,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        holder.texto.text = spannable
    }


    override fun getItemCount(): Int = transacciones.size
}
