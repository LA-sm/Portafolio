package com.appcrud.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.appcrud.R
import com.appcrud.apoyo.Balance

class BalanceAdapter(private val balanceList: List<Balance>) :
    RecyclerView.Adapter<BalanceAdapter.BalanceViewHolder>() {

    inner class BalanceViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val aliasText: TextView = view.findViewById(R.id.participanteAlias)
        val balanceText: TextView = view.findViewById(R.id.textImporteTotal)
        val avatarText: TextView = view.findViewById(R.id.avatarIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BalanceViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_balance, parent, false)
        return BalanceViewHolder(view)
    }

    override fun onBindViewHolder(holder: BalanceViewHolder, position: Int) {
        val balance = balanceList[position]
        val context = holder.itemView.context

        // Set texto del alias y avatar
        holder.aliasText.text = balance.alias
        holder.avatarText.text = balance.alias.trim().firstOrNull()?.uppercase() ?: "?"

        // Balance y color según valor
        val isNegative = balance.balance < 0
        var formattedBalance = "${"%.2f".format(balance.balance)} €"
        val color = if (isNegative) Color.RED
        else ContextCompat.getColor(context, R.color.primary_light_blue)

        if (balance.balance > 0){
            formattedBalance = "+${"%.2f".format(balance.balance)} €"
        }

        holder.balanceText.text = formattedBalance
        holder.balanceText.setTextColor(color)
        holder.avatarText.background.setTint(color)
    }

    override fun getItemCount(): Int = balanceList.size
}
