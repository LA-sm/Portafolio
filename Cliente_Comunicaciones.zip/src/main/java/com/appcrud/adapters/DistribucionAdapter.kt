package com.appcrud.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import billsapppojos.DistribucionGasto
import com.appcrud.R

class DistribucionAdapter(
    private val distribuciones: List<DistribucionGasto>
) : RecyclerView.Adapter<DistribucionAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val avatarIcon: TextView = view.findViewById(R.id.avatarIcon)
        val participanteAlias: TextView = view.findViewById(R.id.participanteAlias)
        val textCantidad: TextView = view.findViewById(R.id.textCantidad)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_distribucion, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val distribucion = distribuciones[position]
        val alias = distribucion.participante.alias.trim()
        val context = holder.itemView.context

        // Asignar datos al layout
        holder.avatarIcon.text = alias.firstOrNull()?.uppercase()?.toString() ?: "?"
        holder.participanteAlias.text = alias
        holder.textCantidad.text = "${"%.2f".format(distribucion.cantidad)} €"

        val azul = ContextCompat.getColor(context, R.color.primary_light_blue)
        holder.avatarIcon.background.setTint(azul)
    }

    override fun getItemCount(): Int = distribuciones.size
}