package com.appcrud.adapters

import android.content.Context
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import billsapppojos.Gasto
import com.appcrud.R
import java.text.SimpleDateFormat
import java.util.Locale

class CustomAdapterGastos(
    private val context: Context,
    private val gastos: MutableList<Gasto>
) : BaseAdapter() {

    override fun getCount(): Int = gastos.size
    override fun getItem(position: Int): Any = gastos[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.list_item_gastos, parent, false)

        val gasto = gastos[position]
        val formato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

        view.findViewById<TextView>(R.id.fecha).text = formato.format(gasto.fecha)
        view.findViewById<TextView>(R.id.descripcion).text = gasto.descripcion
        view.findViewById<TextView>(R.id.importe).text = gasto.importeTotal.toString() + " €"
        val pagador = view.findViewById<TextView>(R.id.pagador)
        val alias = gasto.participantePagador.alias
        val texto = "Pagado por $alias"

        // Crear un SpannableString
        val spannable = SpannableString(texto)

        // Aplicar negrita solo al alias
        val start = texto.indexOf(alias)
        val end = start + alias.length
        spannable.setSpan(
            StyleSpan(Typeface.BOLD),
            start,
            end,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        pagador.text = spannable

        return view
    }
}
