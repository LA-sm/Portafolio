package com.appcrud.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import billsapppojos.Grupo
import com.appcrud.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CustomAdapter(
    private val context: Context,
    private val grupos: MutableList<Grupo>
) : BaseAdapter() {

    override fun getCount(): Int = grupos.size
    override fun getItem(position: Int): Any = grupos[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view =
            convertView ?: LayoutInflater.from(context).inflate(R.layout.list_item_grupos, parent, false)

        val grupo = grupos[position]

        val textFecha = view.findViewById<TextView>(R.id.fecha)
        val textNombre = view.findViewById<TextView>(R.id.nombre)

        val fecha: Date = grupo.fechaCreacion

        val formato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val fechaFormateada = formato.format(fecha)

        textFecha.text = fechaFormateada.toString()
        textNombre.text = grupo.nombre

        return view
    }
}