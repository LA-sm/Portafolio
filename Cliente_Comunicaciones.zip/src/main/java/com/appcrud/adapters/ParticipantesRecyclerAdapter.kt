package com.appcrud.adapters

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.appcrud.R
import com.appcrud.apoyo.DecimalDigitsInputFilter
import com.appcrud.apoyo.ParticipanteConImporte

class ParticipantesRecyclerAdapter(
    private val participantes: MutableList<ParticipanteConImporte>,
    private val onChangeListener: () -> Unit
) : RecyclerView.Adapter<ParticipantesRecyclerAdapter.ParticipanteViewHolder>() {

    inner class ParticipanteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val checkBoxUsuario: CheckBox = view.findViewById(R.id.checkBoxUsuario)
        val editImporte: EditText = view.findViewById(R.id.importe)
        var textWatcher: TextWatcher? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ParticipanteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_participantes_de_grupo, parent, false)
        return ParticipanteViewHolder(view)
    }

    override fun onBindViewHolder(holder: ParticipanteViewHolder, position: Int) {
        val item = participantes[position]

        // Configuramos nombre
        holder.checkBoxUsuario.text = item.nombre

        // Evitar duplicación de listeners
        holder.textWatcher?.let {
            holder.editImporte.removeTextChangedListener(it)
        }

        // Estado de checkbox y campo de texto
        holder.checkBoxUsuario.setOnCheckedChangeListener(null)
        holder.checkBoxUsuario.isChecked = item.isChecked
        holder.editImporte.isEnabled = item.isChecked

        // Solo si el texto cambia realmente
        if (holder.editImporte.text.toString() != item.importe) {
            holder.editImporte.setText(item.importe)
        }

        // Listener para guardar el cambio al perder el foco
        holder.editImporte.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus && holder.editImporte.isEnabled) {
                item.importe = holder.editImporte.text.toString()
            }
        }

        // Listener para check
        holder.checkBoxUsuario.setOnCheckedChangeListener { _, isChecked ->
            item.isChecked = isChecked
            holder.editImporte.isEnabled = isChecked

            if (!isChecked) {
                item.importe = ""
                holder.editImporte.setText("")
            }

            onChangeListener()
        }


        // Filtro para que el importe tenga como límite 4 dígitos antes de la coma y 2 luego de ella
        holder.editImporte.filters = arrayOf(DecimalDigitsInputFilter(4, 2))

        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (holder.editImporte.hasFocus() && holder.editImporte.isEnabled) {
                    item.importe = s?.toString() ?: ""
                    onChangeListener() // 👈 Notifica cambio
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }


        holder.editImporte.addTextChangedListener(watcher)
        holder.textWatcher = watcher

        animateView(holder.itemView)
    }

    override fun getItemCount(): Int = participantes.size

    private fun animateView(view: View) {
        view.alpha = 0f
        view.translationX = 300f // Empieza desplazado a la derecha

        view.animate()
            .translationX(0f)
            .alpha(1f)
            .setDuration(400)
            .start()
    }
}