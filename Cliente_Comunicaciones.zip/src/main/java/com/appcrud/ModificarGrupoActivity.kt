package com.appcrud

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.animation.Animation
import android.view.animation.OvershootInterpolator
import android.view.animation.TranslateAnimation
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import billsapppojos.Grupo
import billsapppojos.Participante
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.ArrayList

class ModificarGrupoActivity : AppCompatActivity() {

    //Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    //Declaración de variables en el contexto de clase para usarlas en otros métodos
    private var listaAlias: ArrayList<String> = arrayListOf()
    private var listaParticipantes: List<Participante> = listOf()
    private lateinit var dynamicContainer: LinearLayout
    private lateinit var addButton: Button
    private lateinit var btnEditar: Button
    private lateinit var editNombre: EditText
    private lateinit var nombreLayout: TextInputLayout
    private lateinit var nombreGrupoOriginal: String
    private var aliasOriginales: List<String> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_modificar_grupo)

        //Obtenemos los datos del intent
        val grupo: Grupo? = intent.getSerializableExtra("grupo") as? Grupo


        val botonVolver = findViewById<ImageButton>(R.id.btnVolver)
        val textNombreGrupo = findViewById<TextView>(R.id.textNombreGrupo)
        dynamicContainer = findViewById(R.id.dynamicContainer)
        addButton = findViewById(R.id.botonAnadirParticipante)
        btnEditar = findViewById(R.id.botonEditarGrupo)
        editNombre = findViewById(R.id.editTextNombreGrupo)
        nombreLayout = findViewById(R.id.layoutNombreGrupo)

        //Le damos el valor a los campos editText y textView de nombre de grupo
        textNombreGrupo.setText(grupo?.nombre)
        editNombre.setText(grupo?.nombre)

        //Obtenemos en tiempo real si han habido cambios en el campo de nombre
        editNombre.addTextChangedListener { checkForChanges() }

        //Inicializamos el nombre de grupo original
        nombreGrupoOriginal = grupo?.nombre ?: ""

        //Filtro para limitar el tamaño del alias a 50 caracteres
        editNombre.filters = arrayOf(InputFilter.LengthFilter(50))

        // Validación en tiempo real del nombre del grupo
        editNombre.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val nombre = s.toString()
                nombreLayout.error = when {
                    nombre.isBlank() -> "El nombre no puede estar vacío"
                    !nombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                    nombre.length < 2 -> "Mínimo 2 caracteres"
                    nombre.length > 50 -> "Máximo 50 caracteres"
                    else -> null
                }
                btnEditar.isEnabled = nombre.isNotEmpty() && dynamicContainer.childCount > 0
                btnEditar.alpha = if (btnEditar.isEnabled) 1f else 0.5f
            }
        })

        //Petición de manera asíncrona al servidor para que nos dé los participantes del grupo
        val peticion = Peticion(Peticion.TipoOperacion.BUSCAR_PARTICIPANTE_POR_GRUPO, grupo?.grupoId)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val socket = ClienteSocket(HOST, PUERTO)
                    val respuesta = socket.enviarPeticion(peticion)
                    listaAlias = respuesta.listaParticipantes.map { it.alias } as ArrayList<String>
                    listaParticipantes = respuesta.listaParticipantes

                    withContext(Dispatchers.Main) {
                        displayParticipantes(listaAlias)
                        aliasOriginales = listaAlias.toList()
                        checkForChanges()
                    }
                }
            }catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Error en la conexión")
                }
            }

        }

        //Añadimos un nuevo campo al contenedor
        addButton.setOnClickListener {
            val isLastEditTextNotEmpty = isLastEditTextNotEmpty()

            // Verificar si hay algún error en los participantes
            val hasErrors = (0 until dynamicContainer.childCount).any { i ->
                val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: return@any true
                val inputLayout = row.getChildAt(0) as? TextInputLayout ?: return@any true
                val text = inputLayout.editText?.text?.toString()?.trim()
                text.isNullOrEmpty() || inputLayout.error != null
            }

            if (!isLastEditTextNotEmpty || hasErrors) {
                // Si el último campo de texto está vacío, hacerle shake y vibrar
                if (!isLastEditTextNotEmpty) {
                    val lastRow = dynamicContainer.getChildAt(dynamicContainer.childCount - 1) as? LinearLayout
                    lastRow?.let {
                        val inputLayout = it.getChildAt(0) as? TextInputLayout
                        inputLayout?.let { layout ->
                            if (layout.editText?.text?.toString().isNullOrEmpty()) {
                                shakeView(layout)
                                vibratePhone()
                            }
                        }
                    }
                }

                // Si hay errores en los campos de los participantes, también hacerles shake y vibrar
                for (i in 0 until dynamicContainer.childCount) {
                    val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
                    val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
                    val text = inputLayout.editText?.text?.toString()?.trim()

                    // Si el campo tiene error, hacerle shake y vibrar
                    if (inputLayout.error != null || text.isNullOrEmpty()) {
                        shakeView(inputLayout)
                        vibratePhone()
                    }
                }
            } else {
                // Si todo está correcto, agregar un participante y mover el foco al siguiente campo
                addDynamicView()

                // Mover el foco al nuevo campo de texto
                val lastRow = dynamicContainer.getChildAt(dynamicContainer.childCount - 1) as? LinearLayout
                lastRow?.let {
                    val inputLayout = it.getChildAt(0) as? TextInputLayout
                    inputLayout?.editText?.requestFocus() // Mover el foco al nuevo campo
                }
            }
        }

        //Editar grupo y participantes al presionar botón
        btnEditar.setOnClickListener {
            val grupoNombre = editNombre.text.toString().trim()

            // Validación del nombre del grupo
            val errorNombre = when {
                grupoNombre.isNullOrEmpty() -> "El nombre no puede estar vacío"
                !grupoNombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                grupoNombre.length < 2 -> "Mínimo 2 caracteres"
                grupoNombre.length > 50 -> "Máximo 50 caracteres"
                else -> null
            }
            nombreLayout.error = errorNombre
            nombreLayout.isErrorEnabled = errorNombre != null

            // Validar que no haya errores en los participantes
            val hasErrors = (0 until dynamicContainer.childCount).any { i ->
                val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: return@any true
                val inputLayout = row.getChildAt(0) as? TextInputLayout ?: return@any true
                val text = inputLayout.editText?.text?.toString()?.trim()
                text.isNullOrEmpty() || inputLayout.error != null
            }

            // Aplicar efectos de error si hay errores
            if (errorNombre != null || hasErrors) {
                // Si el nombre del grupo tiene error, hacer shake y vibrar
                if (errorNombre != null) {
                    shakeView(nombreLayout)  // Añade el efecto de shake al campo de nombre
                    vibratePhone()           // Vibrar el teléfono
                }

                // Si algún campo de participantes tiene error, hacer shake y vibrar
                for (i in 0 until dynamicContainer.childCount) {
                    val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
                    val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
                    val text = inputLayout.editText?.text?.toString()?.trim()

                    if (inputLayout.error != null || text.isNullOrEmpty()) {
                        shakeView(inputLayout)  // Efecto de shake en el campo de participante con error
                        vibratePhone()          // Vibrar el teléfono
                    }
                }
                return@setOnClickListener
            }

            //Obtenemos los participantes existentes y nos nuevos añadidos
            val (nuevos, existentes) = getNuevosYExistentes()

            if (grupo != null) {
                grupo.nombre = grupoNombre
            }

            //Realizamos la petición asíncrona al servidor para actualizar el grupo
            val peticion = Peticion(Peticion.TipoOperacion.UPDATE_GRUPO, grupo)
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticion)

                    if (!respuesta.isExito) return@withContext

                    //Actualización de participantes existentes
                    var exitoEditPart = true
                    for (i in existentes.indices) {
                        listaParticipantes[i].alias = existentes[i]
                        val peticionEditPart = Peticion(Peticion.TipoOperacion.UPDATE_PARTICIPANTE, listaParticipantes[i])
                        val respuestaEditPart = ClienteSocket(HOST, PUERTO).enviarPeticion(peticionEditPart)
                        if (!respuestaEditPart.isExito) {
                            exitoEditPart = false
                            break
                        }
                    }

                    //Creación de participantes añadidos
                    var exitoInsertPart = true
                    for (i in nuevos.indices) {
                        val participante = Participante(i, Grupo(grupo?.grupoId), nuevos[i])
                        val peticionInsertPart = Peticion(Peticion.TipoOperacion.CREATE_PARTICIPANTE, participante)
                        val respuestaInsertPart = ClienteSocket(HOST, PUERTO).enviarPeticion(peticionInsertPart)
                        if (!respuestaInsertPart.isExito) {
                            exitoInsertPart = false
                            break
                        }
                    }

                    //Mensaje de éxito si todo fue bien
                    if (exitoEditPart && exitoInsertPart) {
                        val colorFondo = Color.parseColor("#4FC3F7")
                        withContext(Dispatchers.Main) {
                            // Creamos y mostramos el Snackbar
                            val snackbar = Snackbar.make(findViewById(R.id.layoutModificarGrupo), respuesta.mensaje, Snackbar.LENGTH_SHORT)
                            snackbar.setBackgroundTint(colorFondo)
                            snackbar.setTextColor(Color.WHITE)
                            snackbar.setAction("Cerrar") {
                                snackbar.dismiss() //
                            }
                            snackbar.show()
                            delay(1500)

                            val intent = Intent(this@ModificarGrupoActivity, GruposActivity::class.java)
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            startActivity(intent)
                            finish()
                        }
                    }
                }
            }
        }

        //Volver a GruposActivity
        botonVolver.setOnClickListener {
            val intent = Intent(this, GruposActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Añade dinámicamente un nuevo campo participante
    private fun addDynamicView() {
        val inflater = LayoutInflater.from(this)

        val rowLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 20)
            }
        }

        // Infla una vista input_text_field
        val textInputLayout = inflater.inflate(R.layout.input_text_field, dynamicContainer, false) as TextInputLayout

        textInputLayout.layoutParams = LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        )

        val editText = textInputLayout.editText as TextInputEditText

        //Filtro para limitar el tamaño del editText a 31 caracteres
        editText.filters = arrayOf(InputFilter.LengthFilter(31))

        //Validación en tiempo real del editText
        editText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val nombre = s.toString()
                val errorMsg = when {
                    nombre.isBlank() -> "No puede estar vacío"
                    !nombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                    nombre.length < 2 -> "Mínimo 2 caracteres"
                    nombre.length > 30 -> "Máximo 30 caracteres"
                    getParticipantsNames().count { it == nombre } > 1 -> "Nombre duplicado"
                    else -> null
                }
                textInputLayout.error = errorMsg
                textInputLayout.isErrorEnabled = errorMsg != null

                val allValid = (0 until dynamicContainer.childCount).all { i ->
                    val row = dynamicContainer.getChildAt(i) as LinearLayout
                    val inputLayout = row.getChildAt(0) as? TextInputLayout
                    val text = inputLayout?.editText?.text.toString()
                    inputLayout?.error == null && text.isNotBlank()
                }

                btnEditar.isEnabled = allValid
                btnEditar.alpha = if (allValid) 1f else 0.5f
            }
        })

        //Botón de eliminar participante
        val deleteButton = Button(this).apply {
            background = ContextCompat.getDrawable(context, R.drawable.ic_cancel)
            val sizeInPx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                30f,
                resources.displayMetrics
            ).toInt()

            layoutParams = LinearLayout.LayoutParams(sizeInPx, sizeInPx).apply {
                val marginInPx = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    16f,
                    resources.displayMetrics
                ).toInt()
                setMargins(marginInPx, 0, 0, 0)
                gravity = Gravity.CENTER_VERTICAL
            }

            //Acción de eliminar fila participante
            setOnClickListener {
                val index = dynamicContainer.indexOfChild(rowLayout)

                val previousInput = if (index > 0) {
                    val previousRow = dynamicContainer.getChildAt(index - 1) as LinearLayout
                    val prevInputLayout = previousRow.getChildAt(0) as? TextInputLayout
                    prevInputLayout?.editText
                } else null

                // Animación de slide out + fade
                rowLayout.animate()
                    .translationX(rowLayout.width.toFloat()) // Se desliza hacia la derecha
                    .alpha(0f) // Y se desvanece
                    .setDuration(300)
                    .withEndAction {
                        dynamicContainer.removeView(rowLayout)
                        previousInput?.requestFocus()
                    }
                    .start()
            }

        }

        //Añadimos el input_text_field y el botón ala fila
        rowLayout.addView(textInputLayout)
        rowLayout.addView(deleteButton)

        //Añadimos la fila al contenedor
        dynamicContainer.addView(rowLayout)
    }

    // Método que obtiene una lista de nombres del contenedor
    private fun getParticipantsNames(): List<String> {
        val nombres = mutableListOf<String>()
        for (i in 0 until dynamicContainer.childCount) {
            val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
            val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
            val text = inputLayout.editText?.text?.toString()?.trim()
            if (!text.isNullOrEmpty()) {
                nombres.add(text)
            }
        }
        return nombres
    }

    //Comprueba que el último campo no este vacío
    private fun isLastEditTextNotEmpty(): Boolean {
        val lastIndex = dynamicContainer.childCount - 1
        if (lastIndex < 0) return false

        val lastRow = dynamicContainer.getChildAt(lastIndex) as? LinearLayout ?: return false
        val inputLayout = lastRow.getChildAt(0) as? TextInputLayout ?: return false
        val editText = inputLayout.editText ?: return false

        return editText.text?.toString()?.trim()?.isNotEmpty() == true
    }

    //Obtenemos los participantes que ya existían y los nuevos
    private fun getNuevosYExistentes(): Pair<List<String>, List<String>> {
        val nuevos = mutableListOf<String>()
        val existentes = mutableListOf<String>()

        for (i in 0 until dynamicContainer.childCount) {
            val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
            val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
            val alias = inputLayout.editText?.text?.toString()?.trim() ?: continue

            if (i < listaParticipantes.size) {
                existentes.add(alias)
            } else {
                nuevos.add(alias)
            }
        }

        return Pair(nuevos, existentes)
    }

    //Añadimos los participantes del grupo existentes al contenedor por defecto
    private fun displayParticipantes(listaAlias: List<String>) {
        dynamicContainer.removeAllViews()
        for (alias in listaAlias) {
            addParticipanteExistenteView(alias)
        }
    }

    //Lógica de añadir los participantes existentes al contenedor
    private fun addParticipanteExistenteView(alias: String) {
        val inflater = LayoutInflater.from(this)

        val rowLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 20)
            }
        }

        //Inflamos la vista input_text_field
        val textInputLayout = inflater.inflate(R.layout.input_text_field, dynamicContainer, false) as TextInputLayout

        textInputLayout.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val editText = textInputLayout.editText as TextInputEditText

        //Añadimos el alias correspondiente como valor del editText
        editText.setText(alias)
        editText.isEnabled = true

        //Validación en tiempo real para el editText
        editText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                validarAliasDuplicados()
                checkForChanges()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                validarAliasDuplicados()
                checkForChanges()
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val nombre = s.toString()
                val errorMsg = when {
                    nombre.isBlank() -> "No puede estar vacío"
                    !nombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                    nombre.length < 2 -> "Mínimo 2 caracteres"
                    nombre.length > 30 -> "Máximo 30 caracteres"
                    getParticipantsNames().count { it == nombre } > 1 -> "Nombre duplicado"
                    else -> null
                }
                textInputLayout.error = errorMsg
                textInputLayout.isErrorEnabled = errorMsg != null

                val allValid = (0 until dynamicContainer.childCount).all { i ->
                    val row = dynamicContainer.getChildAt(i) as LinearLayout
                    val inputLayout = row.getChildAt(0) as? TextInputLayout
                    val text = inputLayout?.editText?.text.toString()
                    inputLayout?.error == null && text.isNotBlank()
                }

                btnEditar.isEnabled = allValid
                btnEditar.alpha = if (allValid) 1f else 0.5f
            }
        })

        rowLayout.addView(textInputLayout)

        // Inicializamos opacidad y posición para animar
        rowLayout.alpha = 0f
        rowLayout.translationX = 100f

        dynamicContainer.addView(rowLayout)

        // Calculamos el retraso basado en el número de hijos (efecto cascada)
        val delay = 50L * (dynamicContainer.childCount - 1)

        rowLayout.animate()
            .translationX(0f)
            .alpha(1f)
            .setDuration(500)
            .setStartDelay(delay)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()
    }

    //Mostrar mensaje de error
    private fun showError(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }

    //Verificar si han habido cambios en los campos comparando los valores iniciales con los actuales
    private fun checkForChanges() {
        val nombreActual = editNombre.text.toString().trim()
        val nombreCambiado = nombreActual != nombreGrupoOriginal

        val aliasActuales = mutableListOf<String>()
        for (i in 0 until dynamicContainer.childCount) {
            val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
            val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
            val alias = inputLayout.editText?.text?.toString()?.trim() ?: continue
            aliasActuales.add(alias)
        }

        val aliasCambiados = aliasActuales != aliasOriginales

        btnEditar.isEnabled = aliasActuales.all { it.isNotBlank() } &&
                dynamicContainer.childCount > 0 &&
                (nombreCambiado || aliasCambiados)
        btnEditar.alpha = if (btnEditar.isEnabled) 1f else 0.5f
    }

    //Validamos si existen participantes duplicados en el conetender
    private fun validarAliasDuplicados() {
        // Obtener todos los alias actuales
        val aliasActualizados = mutableListOf<String>()

        for (i in 0 until dynamicContainer.childCount) {
            val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
            val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
            val alias = inputLayout.editText?.text.toString().trim()

            if (alias.isNotEmpty()) {
                aliasActualizados.add(alias)
            }
        }

        // Buscar alias duplicados
        val aliasDuplicados = aliasActualizados.groupBy { it }
            .filter { it.value.size > 1 }
            .keys

        // Recorrer todos los campos
        for (i in 0 until dynamicContainer.childCount) {
            val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
            val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
            val alias = inputLayout.editText?.text.toString().trim()

            val yaTieneOtroError = inputLayout.error != null && inputLayout.error != "Alias duplicado"

            if (aliasDuplicados.contains(alias)) {
                // Solo establecer el error si no hay otro distinto
                if (!yaTieneOtroError) {
                    inputLayout.error = "Alias duplicado"
                }
            } else {
                // Si el error actual es "Alias duplicado", lo limpiamos
                if (inputLayout.error == "Alias duplicado") {
                    inputLayout.error = null
                    inputLayout.isErrorEnabled = false
                }
            }
        }
    }

    // Vibración corta para feedback táctil
    private fun vibratePhone() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(150)
        }
    }

    // Animación shake para vistas (indicar error)
    private fun shakeView(view: View) {
        val anim = TranslateAnimation(0f, 10f, 0f, 0f).apply {
            duration = 100
            repeatMode = Animation.REVERSE
            repeatCount = 3
        }
        view.startAnimation(anim)
    }

}