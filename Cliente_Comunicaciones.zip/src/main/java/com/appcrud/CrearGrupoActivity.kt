package com.appcrud

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.*
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.animation.Animation
import android.view.animation.OvershootInterpolator
import android.view.animation.TranslateAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import billsapppojos.Grupo
import billsapppojos.Participante
import billsapppojos.Usuario
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import java.util.*

class CrearGrupoActivity : AppCompatActivity() {

    //Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    private lateinit var dynamicContainer: LinearLayout
    private lateinit var addButton: Button
    private lateinit var editNombre: TextInputEditText
    private lateinit var botonCrearGrupo: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_crear_grupo)

        //Obtenemos las valores de SharedPreferences
        val prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        val idUserActual = prefs.getInt("idActual", 0)
        val aliasActual = prefs.getString("aliasActual", null)

        //Inicilizamos y creamos las vistas
        dynamicContainer = findViewById(R.id.dynamicContainer)
        addButton = findViewById(R.id.botonAnadirParticipante)
        botonCrearGrupo = findViewById(R.id.botonCrearGrupo)
        val botonVolver = findViewById<ImageButton>(R.id.btnVolver)
        editNombre = findViewById(R.id.editTextNombreGrupo)
        val nombreLayout = findViewById<TextInputLayout>(R.id.layoutNombreGrupo)

        // Verifica si aliasActual no es nulo y agrega el primer participante
        if (!aliasActual.isNullOrEmpty()) {
            addFirstParticipant(aliasActual)
        }

        //Tamaño máximo de 50 caracteres para el campo de nombre
        editNombre.filters = arrayOf(InputFilter.LengthFilter(50))

        //Validación en tiempo real del nombre
        editNombre.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val nombre = s.toString()
                nombreLayout.error = when {
                    nombre.isBlank() -> "El nombre no puede estar vacío"
                    !nombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                    nombre.length < 2 -> "Mínimo 2 caracteres"
                    nombre.length > 50 -> "Máximo 50 caracteres"
                    else -> null
                }
                botonCrearGrupo.isEnabled = nombre.isNotEmpty() && dynamicContainer.childCount > 0
                botonCrearGrupo.alpha = if (botonCrearGrupo.isEnabled) 1f else 0.5f
                nombreLayout.isErrorEnabled = nombreLayout.error != null
            }
        })


        //Añadimos un nuevo campo al contenedor
        addButton.setOnClickListener {
            val isLastEditTextNotEmpty = isLastEditTextNotEmpty()

            // Verificar si hay algún error en los participantes
            val hasErrors = (0 until dynamicContainer.childCount).any { i ->
                val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: return@any true
                val inputLayout = row.getChildAt(0) as? TextInputLayout ?: return@any true
                val text = inputLayout.editText?.text?.toString()?.trim()
                text.isNullOrEmpty() || inputLayout.error != null
            }

            if (!isLastEditTextNotEmpty || hasErrors) {
                // Si el último campo de texto está vacío, hacerle shake y vibrar
                if (!isLastEditTextNotEmpty) {
                    val lastRow = dynamicContainer.getChildAt(dynamicContainer.childCount - 1) as? LinearLayout
                    lastRow?.let {
                        val inputLayout = it.getChildAt(0) as? TextInputLayout
                        inputLayout?.let { layout ->
                            if (layout.editText?.text?.toString().isNullOrEmpty()) {
                                shakeView(layout)
                                vibratePhone()
                            }
                        }
                    }
                }

                // Si hay errores en los campos de los participantes, también hacerles shake y vibrar
                for (i in 0 until dynamicContainer.childCount) {
                    val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
                    val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
                    val text = inputLayout.editText?.text?.toString()?.trim()

                    // Si el campo tiene error, hacerle shake y vibrar
                    if (inputLayout.error != null || text.isNullOrEmpty()) {
                        shakeView(inputLayout)
                        vibratePhone()
                    }
                }
            } else {
                // Si todo está correcto, agregar un participante y mover el foco al siguiente campo
                addDynamicView()

                // Mover el foco al nuevo campo de texto
                val lastRow = dynamicContainer.getChildAt(dynamicContainer.childCount - 1) as? LinearLayout
                lastRow?.let {
                    val inputLayout = it.getChildAt(0) as? TextInputLayout
                    inputLayout?.editText?.requestFocus() // Mover el foco al nuevo campo
                }
            }
        }


        //Creamos el grupo y los participantes al presionar el botón
        botonCrearGrupo.setOnClickListener {
            val grupoNombre = editNombre.text?.toString()?.trim()
            val nombreLayout = findViewById<TextInputLayout>(R.id.layoutNombreGrupo)

            // Validación del nombre del grupo
            val errorNombre = when {
                grupoNombre.isNullOrEmpty() -> "El nombre no puede estar vacío"
                !grupoNombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                grupoNombre.length < 2 -> "Mínimo 2 caracteres"
                grupoNombre.length > 50 -> "Máximo 50 caracteres"
                else -> null
            }
            nombreLayout.error = errorNombre
            nombreLayout.isErrorEnabled = errorNombre != null

            // Validar que no haya errores en los participantes
            val hasErrors = (0 until dynamicContainer.childCount).any { i ->
                val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: return@any true
                val inputLayout = row.getChildAt(0) as? TextInputLayout ?: return@any true
                val text = inputLayout.editText?.text?.toString()?.trim()
                text.isNullOrEmpty() || inputLayout.error != null
            }

            // Aplicar efectos de error si hay errores
            if (errorNombre != null || hasErrors) {
                // Si el nombre del grupo tiene error, hacer shake y vibrar
                if (errorNombre != null) {
                    shakeView(nombreLayout)  // Añade el efecto de shake al campo de nombre
                    vibratePhone()           // Vibrar el teléfono
                }

                // Si algún campo de participantes tiene error, hacer shake y vibrar
                for (i in 0 until dynamicContainer.childCount) {
                    val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
                    val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
                    val text = inputLayout.editText?.text?.toString()?.trim()

                    if (inputLayout.error != null || text.isNullOrEmpty()) {
                        shakeView(inputLayout)  // Efecto de shake en el campo de participante con error
                        vibratePhone()          // Vibrar el teléfono
                    }
                }
                return@setOnClickListener
            }

            // Si todo está correcto, proceder a crear el grupo
            val fechaActual = Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant())
            val grupo = Grupo(grupoNombre, fechaActual, Usuario(idUserActual), 0)
            val listaParticipantes = getParticipantsNames()

            //Se envia la petición de crear grupo al servidor
            lifecycleScope.launch(Dispatchers.IO) {
                val respuestaGrupo = ClienteSocket(HOST, PUERTO).enviarPeticion(
                    Peticion(Peticion.TipoOperacion.CREATE_GRUPO, grupo)
                )

                //Se crean los participantes si se crea el grupo con éxito
                if (!respuestaGrupo.isExito){
                    val colorFondo = Color.parseColor("#F44336")
                    withContext(Dispatchers.Main) {
                        // Creamos y mostramos el Snackbar
                        val snackbar = Snackbar.make(
                            findViewById(R.id.layoutCrearGrupo),
                            respuestaGrupo.mensaje,
                            Snackbar.LENGTH_SHORT
                        )
                        snackbar.setBackgroundTint(colorFondo)
                        snackbar.setTextColor(Color.WHITE) // Texto blanco para buen contraste
                        snackbar.setAction("Cerrar") {
                            snackbar.dismiss() // El botón "Cerrar" para que el usuario pueda cerrar el Snackbar
                        }
                        snackbar.show()
                        delay(1500)
                    }
                    return@launch
                }

                var exito = true
                var contador = 1
                for (nombre in listaParticipantes) {
                    val participante = Participante(contador++, respuestaGrupo.grupo, nombre)
                    val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(
                        Peticion(Peticion.TipoOperacion.CREATE_PARTICIPANTE, participante)
                    )
                    if (!respuesta.isExito) {
                        exito = false
                        break
                    }
                }

                //Si todo fue bien durante la creación del grupo y los participantes se muestra un snackbar de exito
                //y volvemos a la pantalla GruposActivity
                if (exito) {
                    val colorFondo = Color.parseColor("#4FC3F7")
                    withContext(Dispatchers.Main) {
                        // Creamos y mostramos el Snackbar
                        val snackbar = Snackbar.make(findViewById(R.id.layoutCrearGrupo), respuestaGrupo.mensaje, Snackbar.LENGTH_SHORT)
                        snackbar.setBackgroundTint(colorFondo)
                        snackbar.setTextColor(Color.WHITE)
                        snackbar.setAction("Cerrar") {
                            snackbar.dismiss() //
                        }
                        snackbar.show()
                        delay(1500)
                        val intent = Intent(this@CrearGrupoActivity, GruposActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        startActivity(intent)
                        finish()
                    }
                }
            }
        }

        //Volver a la pantalla GruposActivity
        botonVolver.setOnClickListener {
            val intent = Intent(this, GruposActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layoutCrearGrupo)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    //Añadimos al contenerdor el primer participante que es el creador del grupo (sin botón eliminar)
    @SuppressLint("ResourceAsColor")
    private fun addFirstParticipant(alias: String) {
        val inflater = LayoutInflater.from(this)

        // Inflamos la vista input_text_field
        val textInputLayout = inflater.inflate(R.layout.input_text_field, dynamicContainer, false) as TextInputLayout
        val editText = textInputLayout.editText as TextInputEditText

        //Le ponemos por defecto el alias del usuario actual al campo
        editText.setText(alias)
        editText.isEnabled = true

        //Tamaño máximo del campo
        editText.filters = arrayOf(InputFilter.LengthFilter(31))

        //Validación en tiempo real para el campo
        editText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val nombre = s.toString()
                val errorMsg = when {
                    nombre.isBlank() -> "No puede estar vacío"
                    !nombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                    nombre.length < 2 -> "Mínimo 2 caracteres"
                    nombre.length > 30 -> "Máximo 30 caracteres"
                    getParticipantsNames().count { it == nombre } > 1 -> "Nombre duplicado"
                    else -> null
                }

                textInputLayout.error = errorMsg
                textInputLayout.isErrorEnabled = errorMsg != null

                val allValid = (0 until dynamicContainer.childCount).all { i ->
                    val row = dynamicContainer.getChildAt(i) as LinearLayout
                    val inputLayout = row.getChildAt(0) as? TextInputLayout
                    val text = inputLayout?.editText?.text.toString()
                    inputLayout?.error == null && text.isNotBlank()
                }

                botonCrearGrupo.isEnabled = allValid
                botonCrearGrupo.alpha = if (allValid) 1f else 0.5f
            }
        })

        // Creamos la fila contenedora
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 20)
            }
        }

        row.addView(textInputLayout)

        // Aparece desde más lejos y más lento con rebote fuerte
        row.alpha = 0f
        row.translationX = 300f // Desde más lejos para que se note más

        dynamicContainer.addView(row)

        row.animate()
            .translationX(0f)
            .alpha(1f)
            .setDuration(700) // más lenta
            .setStartDelay(150L) // pequeño retardo para dar énfasis
            .setInterpolator(OvershootInterpolator(1.6f)) // rebote más marcado
            .start()
    }

    // Añade dinámicamente un nuevo campo participante
    private fun addDynamicView() {
        val inflater = LayoutInflater.from(this)

        val rowLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 20)
            }
        }

        // Infla una vista input_text_field
        val textInputLayout = inflater.inflate(R.layout.input_text_field, dynamicContainer, false) as TextInputLayout

        textInputLayout.layoutParams = LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        )

        val editText = textInputLayout.editText as TextInputEditText

        //Filtro para limitar el tamaño del ediText a 31 caracteres
        editText.filters = arrayOf(InputFilter.LengthFilter(31))

        //Validación en tiempo real para el aditText
        editText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val nombre = s.toString()
                val errorMsg = when {
                    nombre.isBlank() -> "No puede estar vacío"
                    !nombre.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                    nombre.length < 2 -> "Mínimo 2 caracteres"
                    nombre.length > 30 -> "Máximo 30 caracteres"
                    getParticipantsNames().count { it == nombre } > 1 -> "Nombre duplicado"
                    else -> null
                }
                textInputLayout.error = errorMsg
                textInputLayout.isErrorEnabled = errorMsg != null

                val allValid = (0 until dynamicContainer.childCount).all { i ->
                    val row = dynamicContainer.getChildAt(i) as LinearLayout
                    val inputLayout = row.getChildAt(0) as? TextInputLayout
                    val text = inputLayout?.editText?.text.toString()
                    inputLayout?.error == null && text.isNotBlank()
                }

                botonCrearGrupo.isEnabled = allValid
                botonCrearGrupo.alpha = if (allValid) 1f else 0.5f
            }
        })

        //Botón de eliminar participante
        val deleteButton = Button(this).apply {
            background = ContextCompat.getDrawable(context, R.drawable.ic_cancel)
            val sizeInPx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                30f,
                resources.displayMetrics
            ).toInt()

            layoutParams = LinearLayout.LayoutParams(sizeInPx, sizeInPx).apply {
                val marginInPx = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    16f,
                    resources.displayMetrics
                ).toInt()
                setMargins(marginInPx, 0, 0, 0)
                gravity = Gravity.CENTER_VERTICAL
            }

            //Acción de eliminar fila participante
            setOnClickListener {
                val index = dynamicContainer.indexOfChild(rowLayout)

                val previousInput = if (index > 0) {
                    val previousRow = dynamicContainer.getChildAt(index - 1) as LinearLayout
                    val prevInputLayout = previousRow.getChildAt(0) as? TextInputLayout
                    prevInputLayout?.editText
                } else null

                // Animación de slide out + fade al eliminar campo
                rowLayout.animate()
                    .translationX(rowLayout.width.toFloat()) // Se desliza hacia la derecha
                    .alpha(0f) // Y se desvanece
                    .setDuration(300)
                    .withEndAction {
                        dynamicContainer.removeView(rowLayout)
                        previousInput?.requestFocus()
                    }
                    .start()
            }

        }

        //Añadimos el input_text_field y el botón a la fila
        rowLayout.addView(textInputLayout)
        rowLayout.addView(deleteButton)
        //Añadimos la fila al contenedor dinámico
        dynamicContainer.addView(rowLayout)
    }

    //Comprueba que el último campo no este vacío
    private fun isLastEditTextNotEmpty(): Boolean {
        if (dynamicContainer.childCount == 0) return false
        val lastRow = dynamicContainer.getChildAt(dynamicContainer.childCount - 1) as? LinearLayout ?: return false
        val inputLayout = lastRow.getChildAt(0) as? TextInputLayout ?: return false
        val text = inputLayout.editText?.text?.toString()?.trim()
        return !text.isNullOrEmpty()
    }

    // Método que obtiene una lista de nombres del contenedor
    private fun getParticipantsNames(): List<String> {
        val nombres = mutableListOf<String>()
        for (i in 0 until dynamicContainer.childCount) {
            val row = dynamicContainer.getChildAt(i) as? LinearLayout ?: continue
            val inputLayout = row.getChildAt(0) as? TextInputLayout ?: continue
            val text = inputLayout.editText?.text?.toString()?.trim()
            if (!text.isNullOrEmpty()) {
                nombres.add(text)
            }
        }
        return nombres
    }


    // Vibración corta para feedback táctil
    private fun vibratePhone() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(150)
        }
    }

    // Animación shake para vistas (indicar error)
    private fun shakeView(view: View) {
        val anim = TranslateAnimation(0f, 10f, 0f, 0f).apply {
            duration = 100
            repeatMode = Animation.REVERSE
            repeatCount = 3
        }
        view.startAnimation(anim)
    }

    // Extensión para evitar NullPointer al evaluar Boolean?
    private fun Boolean?.orFalse() = this ?: false
}
