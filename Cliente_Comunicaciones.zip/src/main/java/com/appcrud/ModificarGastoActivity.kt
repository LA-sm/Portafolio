package com.appcrud

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import billsapppojos.DistribucionGasto
import billsapppojos.Gasto
import billsapppojos.Participante
import com.appcrud.adapters.ParticipantesRecyclerAdapter
import com.appcrud.apoyo.DecimalDigitsInputFilter
import com.appcrud.apoyo.ParticipanteConImporte
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class ModificarGastoActivity : AppCompatActivity() {

    // Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    // Declaración de variables de interfaz
    private lateinit var editDescripcion: TextInputEditText
    private lateinit var editImporte: TextInputEditText
    private lateinit var editFecha: TextInputEditText
    private lateinit var btnEditar: Button

    // Listas de participantes y distribuciones de gastos
    private var participantes: MutableList<Participante> = mutableListOf()
    val listaParticipantesListView: MutableList<ParticipanteConImporte> = mutableListOf()
    private var distribuconesDeGastos: MutableList<DistribucionGasto> = mutableListOf()

    // Participante seleccionado como pagador
    private var participanteSeleccionado: Participante? = null

    //Vraiables para datos originales
    private lateinit var descripcionOriginal:String
    private lateinit var importeOriginal:String
    private lateinit var fechaOriginal:String
    private lateinit var pagadorOriginal:String

    // Variable para modo oscuro
    private var modoOscuro = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_modificar_gasto)

        // Obtener preferencia de modo oscuro
        val prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        modoOscuro = prefs.getBoolean("modoOscuro", false)

        // Obtener el gasto e ID del grupo pasado por intent
        val grupoId = intent.extras?.getInt("grupoId")
        val gasto: Gasto? = intent.getSerializableExtra("gasto") as? Gasto

        // Validación del ID del grupo
        if (grupoId == null) {
            showError("Error: grupoId es nulo")
            finish()
            return
        }

        // Asignación de vistas
        btnEditar = findViewById(R.id.btnEditarGasto)
        val spinnerUsers = findViewById<Spinner>(R.id.spinnerUsers)
        editDescripcion = findViewById(R.id.editDescripcion)
        editImporte = findViewById(R.id.editImporte)
        editFecha = findViewById(R.id.editFecha)
        val textGasto = findViewById<TextView>(R.id.textGrupos)
        val botonVolver = findViewById<ImageButton>(R.id.botonVolver)

        // Asignación de layouts para mostrar errores
        val descripcionLayout = findViewById<TextInputLayout>(R.id.inputLayoutDescripcion)
        val importeLayout = findViewById<TextInputLayout>(R.id.inputLayoutImporte)
        val fechaLayout = findViewById<TextInputLayout>(R.id.inputLayoutFecha)
        val pagadorLayout = findViewById<TextInputLayout>(R.id.inputLayoutPagador)

        // Configuración de RecyclerView para la lista de participantes
        val recyclerViewParticipantes = findViewById<RecyclerView>(R.id.recyclerViewParticipantes)
        recyclerViewParticipantes.layoutManager = LinearLayoutManager(this)

        // Desactivar edición directa del campo de fecha
        btnEditar.isEnabled = false
        btnEditar.alpha = 0.5f

        editFecha.isFocusable = false
        editFecha.isClickable = true

        // Lista para el Spinner (pagador)
        val listaParticipantesSpinner: MutableList<String> = mutableListOf("participante") // HINT como primer elemento

        // Adaptador personalizado para Spinner
        val adapterSpinner = object : ArrayAdapter<String>(this, R.layout.spinner_item, listaParticipantesSpinner) {

            // Deshabilitar selección del primer ítem (hint)
            override fun isEnabled(position: Int): Boolean {
                return position != 0 // Primer ítem como hint (desactivado)
            }

            // Personalizar vista de Spinner
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return createCustomView(position, convertView, parent, isDropdown = false)
            }

            // Personalizar vista desplegable
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                return createCustomView(position, convertView, parent, isDropdown = true)
            }

            // Crea la vista personalizada con íconos y colores
            private fun createCustomView(position: Int, convertView: View?, parent: ViewGroup, isDropdown: Boolean): View {
                val inflater = LayoutInflater.from(context)
                val view = convertView ?: inflater.inflate(R.layout.spinner_item, parent, false)

                val textView = view.findViewById<TextView>(R.id.text)
                val iconView = view.findViewById<ImageView>(R.id.icon)

                textView.text = listaParticipantesSpinner[position]

                // Colores y visibilidad según modo oscuro y si es hint
                if (modoOscuro){
                    if (position == 0) {
                        textView.setTextColor(ContextCompat.getColor(context, android.R.color.darker_gray))
                        iconView.visibility = View.VISIBLE // Muestra ícono como hint
                    } else {
                        textView.setTextColor(ContextCompat.getColor(context, R.color.white))
                        iconView.visibility = View.GONE
                    }
                }else{
                    if (position == 0) {
                        textView.setTextColor(ContextCompat.getColor(context, R.color.light_gray))
                        iconView.visibility = View.VISIBLE // Muestra ícono como hint
                    } else {
                        textView.setTextColor(ContextCompat.getColor(context, android.R.color.black))
                        iconView.visibility = View.GONE
                    }
                }


                return view
            }
        }

        // Configuración final del Spinner
        adapterSpinner.setDropDownViewResource(R.layout.spinner_item)
        spinnerUsers.adapter = adapterSpinner

        // Adaptador para lista de participantes y callback cuando se modifica
        val adapterRecyclerView = ParticipantesRecyclerAdapter(listaParticipantesListView){
            actualizarBotonEditarGasto()
        }
        recyclerViewParticipantes.adapter = adapterRecyclerView

        // Filtro de longitud para descripción
        editDescripcion.filters = arrayOf(InputFilter.LengthFilter(51))

        //Validaciones en tiempo real para descripcion
        editDescripcion.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                actualizarBotonEditarGasto()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val descripcion = s.toString()
                descripcionLayout.error = when {
                    descripcion.isBlank() -> "La descripción del gasto no puede estar vacía"
                    !descripcion.firstOrNull()?.isLetter().orFalse() -> "Debe comenzar con una letra"
                    descripcion.length < 2 -> "Mínimo 2 caracteres"
                    descripcion.length > 51 -> "Máximo 50 caracteres"
                    else -> null
                }
                descripcionLayout.isErrorEnabled = descripcionLayout.error != null
            }
        })

        // Filtro para importe: 6 enteros, 2 decimales
        editImporte.filters = arrayOf(DecimalDigitsInputFilter(6, 2)) // Máx. 6 enteros, 2 decimales

        // Validación en tiempo real del campo de importe
        editImporte.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                actualizarBotonEditarGasto()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val texto = s.toString()
                val valor = texto.toDoubleOrNull()

                importeLayout.error = when {
                    texto.isBlank() -> "El importe no puede estar vacío"
                    valor == null -> "El importe debe ser un número válido"
                    valor <= 0.0 -> "El importe debe ser mayor a 0"
                    valor > 9999.99 -> "El importe no puede superar 9999.99"
                    else -> null
                }
                importeLayout.isErrorEnabled = importeLayout.error != null
            }
        })

        // Crear y enviar petición para obtener los participantes del grupo
        val peticionParticipantes = Peticion(Peticion.TipoOperacion.BUSCAR_PARTICIPANTE_POR_GRUPO, grupoId)
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticionParticipantes)
                withContext(Dispatchers.Main) {
                    if (respuesta.isExito) {
                        // Cargar participantes en Spinner y RecyclerView
                        participantes = respuesta.listaParticipantes
                        listaParticipantesSpinner.clear()
                        listaParticipantesSpinner.add("participante")
                        listaParticipantesSpinner.addAll(participantes.map { it.alias })
                        adapterSpinner.notifyDataSetChanged()

                        // Selecciona al participante pagador en el Spinner
                        gasto?.participantePagador?.alias?.let { aliasPagador ->
                            val index = listaParticipantesSpinner.indexOf(aliasPagador)
                            if (index >= 0) {
                                spinnerUsers.setSelection(index)
                                participanteSeleccionado = participantes.getOrNull(index - 1) // porque el índice 0 es el hint
                            }
                        }

                        // Ahora cargamos las distribuciones y creamos la lista sincronizada
                        cargarDistribuciones(gasto?.gastoId, participantes, adapterRecyclerView)
                    } else {
                        withContext(Dispatchers.Main) {
                            val snackbar = Snackbar.make(
                                findViewById(R.id.layoutEditarGasto),
                                respuesta.mensaje,
                                Snackbar.LENGTH_SHORT
                            )
                            snackbar.setBackgroundTint(Color.parseColor("#F44336"))
                            snackbar.setTextColor(Color.WHITE)
                            snackbar.setAction("Cerrar") {
                                snackbar.dismiss() //
                            }
                            snackbar.show()
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Error en la conexión: ${e.message}")
                }
            }
        }

        //Formateamos la fecha
        val fecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val fechaFormateada = fecha.format(gasto?.fecha)

        //Inicializamos las varaibles con los valores originales
        descripcionOriginal = gasto?.descripcion.orEmpty()
        importeOriginal = gasto?.importeTotal?.toString().orEmpty()
        fechaOriginal = fechaFormateada
        pagadorOriginal = gasto?.participantePagador?.alias.toString()

        //Actualizamos la interfaz con los valores originales
        editDescripcion.setText(gasto?.descripcion)
        textGasto.setText(gasto?.descripcion)
        editImporte.setText(gasto?.importeTotal.toString())
        editFecha.setText(fechaFormateada)

        //Mostramos un calendario para elegir la fecha
        editFecha.setOnClickListener { mostrarDatePicker(editFecha) }

        //Actualizamos el estado del boton crearGasto tras cambiar editFecha
        editFecha.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                actualizarBotonEditarGasto()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        //Lógica al seleccionar un elemento del spinner
        spinnerUsers.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    participanteSeleccionado = participantes[position - 1] // Restamos 1 por el hint
                } else {
                    participanteSeleccionado = null
                }
                actualizarBotonEditarGasto()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        //Editamos un gasto y sus distribuciones
        btnEditar.setOnClickListener {
            val descripcion = editDescripcion.text.toString().trim()
            val importeStr = editImporte.text.toString().trim()
            val fechaStr = editFecha.text.toString().trim()
            var hayError = false

            //Validación del campo desrcipción para comprobar que no tiene errores y no esta vacío
            if (descripcionLayout.error != null || descripcion.isBlank()) {
                vibratePhone()
                shakeView(descripcionLayout)
                hayError = true
            }

            //Validación del campo importe para comprobar que no tiene errores y no esta vacío
            if (importeLayout.error != null || importeStr.isBlank()) {
                vibratePhone()
                shakeView(importeLayout)
                hayError = true
            }

            //Validar que la fecha haya sido seleccionada
            if (fechaStr.isBlank()) {
                vibratePhone()
                shakeView(fechaLayout)
                hayError = true
            }

            //Validar que se haya escogido un pagador
            if (participanteSeleccionado == null) {
                vibratePhone()
                shakeView(pagadorLayout)
                hayError = true
            }

            //Si sucediera algo de lo anterior no editamos el gasto
            if (hayError) return@setOnClickListener

            //Formateamos la fecha
            val formato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val fechaDate = try {
                formato.parse(fechaStr)
            } catch (e: Exception) {
                null
            }

            //Creamos el gasto con los datos recogidos y creamos petición de editar gasto
            val gastoActualizado = Gasto(fechaDate, descripcion, importeStr.toDouble(), participanteSeleccionado, gasto?.gastoId)
            val peticionUpdateGasto = Peticion(Peticion.TipoOperacion.UPDATE_GASTO, gastoActualizado)

            //Lógica de envío y manejo de peticiones al servidor
            lifecycleScope.launch(Dispatchers.IO) {
                //Obtenemos los participantes con importes de la lista de participantes del listView
                val participantesConImporte = obtenerParticipantesConImporte()

                //Clores del snackbar
                val colorFondoError = Color.parseColor("#F44336")
                val colorFondoExito = Color.parseColor("#4FC3F7")

                //Si aun no se ha escogido ningun participante con importe se muestra mensaje y no seguimos
                if (participantesConImporte.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        val snackbar = Snackbar.make(findViewById(R.id.layoutEditarGasto), "Selecciona al menos un participante con importe", Snackbar.LENGTH_SHORT)
                        snackbar.setBackgroundTint(colorFondoError)
                        snackbar.setTextColor(Color.WHITE)
                        snackbar.setAction("Cerrar") {
                            snackbar.dismiss() //
                        }
                        snackbar.show()
                        shakeView(recyclerViewParticipantes)
                        vibratePhone()
                    }
                    return@launch
                }

                //Se comprueba que los importes sumados sean igual al importe total y si no, se muestra mensaje y no seguimos
                val importeCalculado = participantesConImporte.sumOf { it.second }

                when {
                    importeCalculado < gastoActualizado.importeTotal -> {
                        withContext(Dispatchers.Main) {
                            val snackbar = Snackbar.make(findViewById(R.id.layoutEditarGasto), "Falta ${gastoActualizado.importeTotal - importeCalculado} € por repartir", Snackbar.LENGTH_SHORT)
                            snackbar.setBackgroundTint(colorFondoError)
                            snackbar.setTextColor(Color.WHITE)
                            snackbar.setAction("Cerrar") {
                                snackbar.dismiss() //
                            }
                            snackbar.show()
                            shakeView(recyclerViewParticipantes)
                            vibratePhone()
                        }
                        return@launch
                    }

                    importeCalculado > gastoActualizado.importeTotal -> {
                        withContext(Dispatchers.Main) {
                            val snackbar = Snackbar.make(findViewById(R.id.layoutEditarGasto), "Te has excedido en ${importeCalculado - gastoActualizado.importeTotal} €", Snackbar.LENGTH_SHORT)
                            snackbar.setBackgroundTint(colorFondoError)
                            snackbar.setTextColor(Color.WHITE)
                            snackbar.setAction("Cerrar") {
                                snackbar.dismiss() //
                            }
                            snackbar.show()
                            shakeView(recyclerViewParticipantes)
                            vibratePhone()
                        }
                        return@launch
                    }
                }

                //Enviamos petición al servidor para eliminar las distribciones del gasto
                for (distribucion in distribuconesDeGastos) {
                    val peticionDelete = Peticion(Peticion.TipoOperacion.DELETE_DISTRIBUCION, distribucion.distribucionId)
                    val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticionDelete)
                }

                //Enviamos petición al servidor para actualizar el gasto con los nuevos datos
                val respuestaUpdateGasto = ClienteSocket(HOST, PUERTO).enviarPeticion(peticionUpdateGasto)
                if (!respuestaUpdateGasto.isExito){
                    withContext(Dispatchers.Main) {
                        // Creamos y mostramos el Snackbar
                        val snackbar = Snackbar.make(findViewById(R.id.layoutEditarGasto), respuestaUpdateGasto.mensaje, Snackbar.LENGTH_SHORT
                        )
                        snackbar.setBackgroundTint(colorFondoError)
                        snackbar.setTextColor(Color.WHITE)
                        snackbar.setAction("Cerrar") {
                            snackbar.dismiss() //
                        }
                        snackbar.show()
                    }
                    return@launch
                }

                //Volvemos a crear lass distribuciones del gasto con los datos que se encuentran en el recyclerView
                var exitoTotal = true
                for ((index, pair) in participantesConImporte.withIndex()) {
                    val distribucionGasto = DistribucionGasto(pair.second, pair.first, gastoActualizado, index + 1)
                    val peticionCrear = Peticion(Peticion.TipoOperacion.CREATE_DISTRIBUCION, distribucionGasto)
                    val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticionCrear)
                    if (!respuesta.isExito) {
                        exitoTotal = false
                        break
                    }
                }

                //Si todo fue bien mostramos mensaje de éxito
                if (exitoTotal) {
                        withContext(Dispatchers.Main) {
                            // Creamos y mostramos el Snackbar
                            val snackbar = Snackbar.make(findViewById(R.id.layoutEditarGasto), respuestaUpdateGasto.mensaje, Snackbar.LENGTH_SHORT)
                            snackbar.setBackgroundTint(colorFondoExito)
                            snackbar.setTextColor(Color.WHITE)
                            snackbar.setAction("Cerrar") {
                                snackbar.dismiss() //
                            }
                            snackbar.show()
                            delay(1500)

                        intent= Intent(this@ModificarGastoActivity, GastosActivity::class.java)
                        intent.putExtra("grupoId", grupoId)
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        startActivity(intent)
                        finish()
                    }
                }
            }
        }

        botonVolver.setOnClickListener{
            intent= Intent(this, GastosActivity::class.java)
            intent.putExtra("grupoId", grupoId)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            finish()
        }
    }

    //Cargamos las distribuciones del gasto en el RecyclerView
    private fun cargarDistribuciones(
        gastoId: Int?,
        participantes: List<Participante>,
        adapterRecyclerView: ParticipantesRecyclerAdapter
    ) {

        //Creamos petición de buscar distribuciones del gasto
        val peticion = Peticion(Peticion.TipoOperacion.BUSCAR_DISTRIBUCION_POR_GASTO, gastoId)

        //Enviamos la petición al servidor de forma asíncrona
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticion)
                withContext(Dispatchers.Main) {
                    if (respuesta.isExito) {
                        distribuconesDeGastos = respuesta.listaDistribucionGasto

                        listaParticipantesListView.clear()
                        listaParticipantesListView.addAll(participantes.map { p ->
                            val distribucion = distribuconesDeGastos.find { it.participante?.alias == p.alias }
                            if (distribucion != null) {
                                ParticipanteConImporte(p.alias, true, distribucion.cantidad.toString())
                            } else {
                                ParticipanteConImporte(p.alias)
                            }
                        })

                        adapterRecyclerView.notifyDataSetChanged()
                    } else {
                        showError("No se pudo cargar la distribución del gasto")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Error en la conexión: ${e.message}")
                }
            }
        }
    }

    //Método para comprobar si hay cambios en los datos originales
    private fun hayCambios(): Boolean {
        val descripcionActual = editDescripcion.text.toString().trim()
        val importeActual = editImporte.text.toString().trim()
        val fechaActual = editFecha.text.toString().trim()
        val pagadorActual = participanteSeleccionado?.alias

        val camposCambiaron =
            descripcionActual != descripcionOriginal ||
                    importeActual != importeOriginal ||
                    fechaActual != fechaOriginal ||
                    pagadorActual != pagadorOriginal

        val distribucionOriginal = distribuconesDeGastos.mapNotNull { distribucion ->
            distribucion.participante?.alias?.let { alias ->
                alias to distribucion.cantidad
            }
        }.toMap()

        val distribucionActual = listaParticipantesListView
            .filter { it.isChecked }
            .mapNotNull {
                val valor = it.importe.toDoubleOrNull()
                if (valor != null && valor > 0) it.nombre to valor else null
            }.toMap()

        val distribucionCambiada = distribucionOriginal != distribucionActual

        return camposCambiaron || distribucionCambiada
    }

    //Método para mostrar mensaje de error
    private fun showError(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }

    //Método para actualizar el estado del boton actualizar gasto
    private fun actualizarBotonEditarGasto() {
        val habilitar = hayCambios()
        btnEditar.isEnabled = habilitar
        btnEditar.alpha = if (habilitar) 1f else 0.5f
    }

    // Vibra el dispositivo
    private fun vibratePhone() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(150)
        }
    }

    // Anima una vista con efecto de "sacudida"
    private fun shakeView(view: View) {
        val anim = TranslateAnimation(0f, 10f, 0f, 0f).apply {
            duration = 100
            repeatMode = Animation.REVERSE
            repeatCount = 3
        }
        view.startAnimation(anim)
    }

    //Método para mostrar calendario
    private fun mostrarDatePicker(editText: EditText) {
        val calendario = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            val fechaSeleccionada = Calendar.getInstance().apply {
                set(year, month, dayOfMonth)
            }

            val formato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

            val fechaSeleccionadaStr = formato.format(fechaSeleccionada.time)
            editText.setText(fechaSeleccionadaStr)

            // Compara contra la fecha de creación del grupo
            val fechaGrupoStr = getSharedPreferences("datos", Context.MODE_PRIVATE).getString("fechaGrupo", null)
            fechaGrupoStr?.let {
                try {
                    val fechaGrupoDate = formato.parse(it)
                    if (fechaGrupoDate != null && fechaSeleccionada.time.before(fechaGrupoDate)) {
                        Toast.makeText(
                            this,
                            "⚠️ Esta fecha es anterior a la creación del grupo ($it)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (_: Exception) {}
            }
        }, calendario.get(Calendar.YEAR), calendario.get(Calendar.MONTH), calendario.get(Calendar.DAY_OF_MONTH))

        // ✅ CAMBIAR COLOR DE FONDO DEL DATEPICKER
        datePicker.setOnShowListener {
            // Aplica color personalizado (ejemplo: azul claro)
            var colorFondo:Int
            if (modoOscuro){
                colorFondo = ContextCompat.getColor(this, R.color.custom_dark_background)
            }else{
                colorFondo = ContextCompat.getColor(this, R.color.white)
            }
            datePicker.window?.setBackgroundDrawable(ColorDrawable(colorFondo))
        }

        datePicker.show()
    }

    //Método para obtener participantes con importe de la lista participantes en el recyclerView
    private fun obtenerParticipantesConImporte(): List<Pair<Participante, Double>> {
        return listaParticipantesListView.mapNotNull { item ->
            val participante = participantes.find { it.alias == item.nombre }
            val importe = item.importe.toDoubleOrNull()
            if (item.isChecked && importe != null && importe > 0 && participante != null) {
                Pair(participante, importe)
            } else null
        }
    }
}



