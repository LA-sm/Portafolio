package com.appcrud

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logoImage = findViewById<ImageView>(R.id.logoImage)
        val sloganText = findViewById<TextView>(R.id.sloganText)
        val layout = findViewById<ConstraintLayout>(R.id.splashLayout)

        // Animaciones para el logo y el texto
        val logoAnim = AnimationUtils.loadAnimation(this, R.anim.zoom_in)
        logoImage.startAnimation(logoAnim)

        val textAnim = AnimationUtils.loadAnimation(this, R.anim.fade_slide_up)
        sloganText.startAnimation(textAnim)

        val fadeAnim = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        layout.startAnimation(fadeAnim)

        // Obtener el valor de modoOscuro desde SharedPreferences
        val prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        val modoOscuro = prefs.getBoolean("modoOscuro", false) // Default es false (modo claro)

        logoImage.setImageResource(R.drawable.logo) // Usar logo claro

        lifecycleScope.launch {
            delay(2000)
            val usuario = prefs.getString("usuarioActual", null)
            val password = prefs.getString("passwordActual", null)
            val alias = prefs.getString("aliasActual", null)

            if (usuario != null && password != null && alias != null) {
                startActivity(Intent(this@SplashActivity, GruposActivity::class.java))
            } else {
                startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            }
            finish()
        }
    }
}
