package com.appcrud.apoyo

data class ParticipanteConImporte(
    val nombre: String,
    var isChecked: Boolean = false,
    var importe: String = ""
)
