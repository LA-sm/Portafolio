package com.appcrud.apoyo

import android.text.InputFilter
import android.text.Spanned

class DecimalDigitsInputFilter(private val digitsBeforeZero: Int, private val digitsAfterZero: Int) :
    InputFilter {
    private val regex = Regex("[0-9]{0,$digitsBeforeZero}+(\\.[0-9]{0,$digitsAfterZero})?")

    override fun filter(
        source: CharSequence?,
        start: Int,
        end: Int,
        dest: Spanned?,
        dstart: Int,
        dend: Int
    ): CharSequence? {
        val newString = dest?.replaceRange(dstart, dend, source?.subSequence(start, end) ?: "")
        return if (newString != null && regex.matches(newString)) null else ""
    }
}
