package com.appcrud.apoyo

data class Balance(
    val participanteId: Int,
    val alias: String,
    var pagado: Double = 0.0,
    var debe: Double = 0.0
) {
    var balance: Double = 0.0
        get() = pagado - debe
}
