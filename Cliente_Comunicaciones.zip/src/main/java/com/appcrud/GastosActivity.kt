package com.appcrud

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import billsapppojos.Gasto
import com.appcrud.adapters.CustomAdapterGastos
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GastosActivity : AppCompatActivity() {

    // Dirección IP y puerto del servidor al que se conecta la app
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000
    private var grupoId: Int = 0  //ID del grupo actual

    // Lista mutable de gastos y su adaptador personalizado
    private lateinit var listaMutable: MutableList<Gasto>
    private lateinit var adapter: CustomAdapterGastos

    //Vista para mostrar texto si no hay gastos
    private lateinit var textNoGastos:TextView

    @SuppressLint("MissingInflatedId", "ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_gastos)

        // Obtener datos del grupo actual guardado en preferencias
        val prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        grupoId = prefs.getInt("idGrupoActual", 0)
        val grupoNombre = prefs.getString("nombreGrupoActual", "")

        // Referencias a vistas del layout
        val botonAnadirGasto = findViewById<FloatingActionButton>(R.id.botonAnadirGasto)
        val botonVolver = findViewById<ImageButton>(R.id.botonVolver)
        val listViewGastos = findViewById<ListView>(R.id.listViewGastos)
        val textNombreGrupo = findViewById<TextView>(R.id.textGrupos)
        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        val indicator = findViewById<View>(R.id.animatedIndicator)
        textNoGastos = findViewById<TextView>(R.id.textNoGastos)

        textNombreGrupo.text = grupoNombre

        // Configuración de pestañas del menú
        val tabGastos = tabLayout.newTab().setCustomView(createCustomTabView("Gastos"))
        val tabBalance = tabLayout.newTab().setCustomView(createCustomTabView("Deudas"))
        val tabSaldos = tabLayout.newTab().setCustomView(createCustomTabView("Saldos"))

        tabLayout.addTab(tabGastos)
        tabLayout.addTab(tabBalance)
        tabLayout.addTab(tabSaldos)

        tabLayout.selectTab(tabGastos) //Selecciona la pestaña gastos por defecto

        // Ajusta el modo de las pestañas según cantidad
        if (tabLayout.tabCount > 2) {
            tabLayout.tabMode = TabLayout.MODE_SCROLLABLE
        } else {
            tabLayout.tabMode = TabLayout.MODE_FIXED
        }

        // Inicializa la posición del indicador debajo de la pestaña activa
        tabLayout.post {
            val selectedTab = tabLayout.getTabAt(tabLayout.selectedTabPosition)
            selectedTab?.view?.let { tabView ->
                val tabX = tabView.left + tabLayout.left
                indicator.x = tabX.toFloat() + 15
                indicator.layoutParams.width = tabView.width
                indicator.requestLayout()
            }
        }

        // Listener para cambiar entre pestañas
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                val tabView = tab.view
                val tabX = tabView.left + tabLayout.left + 15

                // Colorea texto de la pestaña activa
                val customView = tab.customView
                customView?.findViewById<TextView>(R.id.tabText)?.setTextColor(getColor(R.color.naranja))

                // Animación con rebote del inidicador
                indicator.animate()
                    .x(tabX.toFloat())
                    .setDuration(300)
                    .setInterpolator(OvershootInterpolator(1.2f))  // Añadido el interpolador de rebote
                    .start()

                indicator.layoutParams.width = tabView.width
                indicator.requestLayout()

                // Cambia de actividad según pestaña
                when (tab.position) {
                    0 -> { /* Gastos */ }
                    1 -> {
                        startActivity(Intent(this@GastosActivity, ReembolsosActivity::class.java))
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        finish()
                    }
                    2 -> {
                        startActivity(Intent(this@GastosActivity, SaldosActivity::class.java))
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        finish()
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // Restaura el color del texto al dejar de estar seleccionado
                val customView = tab?.customView
                customView?.findViewById<TextView>(R.id.tabText)?.setTextColor(getColor(R.color.dark_gray))
            }
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        // Inicializa la lista y su adaptador personalizado
        listaMutable = mutableListOf()
        adapter = CustomAdapterGastos(this, listaMutable)
        listViewGastos.adapter = adapter

        // Cargar gastos al iniciar
        cargarGastos()

        //Click corto: ver detalle del gasto en la activity GastoActivity
        listViewGastos.setOnItemClickListener(){_, view, position, _->
            val intent= Intent(this, GastoActivity::class.java)
            intent.putExtra("gasto", listaMutable[position])
            startActivity(intent)
        }

        // Click largo: mostrar opciones de editar/eliminar
        listViewGastos.setOnItemLongClickListener { _, _, position, _ ->
            val bottomSheetView = LayoutInflater.from(this)
                .inflate(R.layout.layout_bottom_sheet_gasto, null)

            val bottomSheetDialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
            bottomSheetDialog.setContentView(bottomSheetView)

            val btnEditar = bottomSheetView.findViewById<LinearLayout>(R.id.btnEditar)
            val btnEliminar = bottomSheetView.findViewById<LinearLayout>(R.id.btnEliminar)

            btnEditar.setOnClickListener {
                bottomSheetDialog.dismiss()
                val intent = Intent(this, ModificarGastoActivity::class.java).apply {
                    putExtra("grupoId", grupoId)
                    putExtra("gasto", listaMutable[position])
                }
                startActivity(intent)
            }

            //Lógica de eliminar ggasto
            btnEliminar.setOnClickListener {
                bottomSheetDialog.dismiss()
                // Confirmación antes de eliminar
                MaterialAlertDialogBuilder(this, R.style.CustomAlertDialog)
                    .setTitle("¡Confirmación!")
                    .setMessage("¿Seguro que deseas eliminar el gasto \"${listaMutable[position].descripcion}\"?")
                    .setIcon(R.drawable.ic_warning)
                    .setPositiveButton("Sí") { dialog, _ ->
                        val peticion = Peticion(Peticion.TipoOperacion.DELETE_GASTO, listaMutable[position].gastoId)
                        lifecycleScope.launch(Dispatchers.IO) {
                            val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticion)

                            var colorFondo:Int
                            if (respuesta.isExito){
                                colorFondo = Color.parseColor("#4FC3F7")
                            }else{
                                colorFondo = Color.parseColor("#F44336")
                            }

                            withContext(Dispatchers.Main) {
                                if (respuesta.isExito) {
                                    listaMutable.removeAt(position)
                                    adapter.notifyDataSetChanged()

                                    // Muestra u oculta mensaje según haya gastos
                                    if (listaMutable.isEmpty()) {
                                        textNoGastos.visibility = View.VISIBLE
                                        listViewGastos.visibility = View.GONE
                                    } else {
                                        textNoGastos.visibility = View.GONE
                                        listViewGastos.visibility = View.VISIBLE
                                    }
                                }else{
                                    Toast.makeText(this@GastosActivity, "Error al obtener los gastos.", Toast.LENGTH_SHORT).show()
                                    textNoGastos.visibility = View.VISIBLE

                                    listViewGastos.visibility = View.GONE
                                }

                                // Muestra snackbar con el mensaje de la respuesta
                                val snackbar = Snackbar.make(findViewById(R.id.main), respuesta.mensaje, Snackbar.LENGTH_SHORT)
                                snackbar.setBackgroundTint(colorFondo)
                                snackbar.setTextColor(Color.WHITE)
                                snackbar.setAction("Cerrar") {
                                    snackbar.dismiss() //
                                }
                                snackbar.show()
                                delay(1500)
                            }
                        }
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancelar") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .show()
            }

            bottomSheetDialog.show()

            true
        }

        // Botón para crear nuevo gasto nos lleva a la pantalla CrearGastoActivity
        botonAnadirGasto.setOnClickListener {
            startActivity(Intent(this, CrearGastoActivity::class.java).apply {
                putExtra("grupoId", grupoId)
            })
        }

        // Volver al menú principal de grupos
        botonVolver.setOnClickListener {
            val intent = Intent(this, GruposActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            finish()
        }

        // Ajuste de márgenes con insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Crea una vista personalizada para cada pestaña
    private fun createCustomTabView(text: String): View {
        val view = LayoutInflater.from(this).inflate(R.layout.custom_tab, null)
        val textView = view.findViewById<TextView>(R.id.tabText)
        textView.text = text
        return view
    }

    // Vuelve a cargar la lista al volver a esta actividad
    override fun onResume() {
        super.onResume()
        cargarGastos()
    }

    //Carga los gastos del servidor y actualiza el adaptador.
    private fun cargarGastos() {
        val listViewGastos = findViewById<ListView>(R.id.listViewGastos)

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val respuesta = ClienteSocket(HOST, PUERTO)
                    .enviarPeticion(Peticion(Peticion.TipoOperacion.BUSCAR_GASTOS_POR_GRUPO, grupoId))

                withContext(Dispatchers.Main) {
                    if (respuesta.isExito) {
                        // Ordenar por fecha descendente y luego por ID descendente
                        val gastosOrdenados = respuesta.listaGastos
                            .sortedWith(
                                compareByDescending<Gasto> { it.fecha }
                                    .thenByDescending { it.gastoId }
                            )

                        listaMutable.clear()
                        listaMutable.addAll(gastosOrdenados)
                        adapter.notifyDataSetChanged()

                        // Mostrar mensaje si la lista está vacía
                        if (listaMutable.isEmpty()) {
                            textNoGastos.visibility = View.VISIBLE
                            listViewGastos.visibility = View.GONE
                        } else {
                            textNoGastos.visibility = View.GONE
                            listViewGastos.visibility = View.VISIBLE
                        }

                    } else {
                        //Mostrar snackbar con el mensaje de la respuesta del servidor
                        val snackbar = Snackbar.make(findViewById(R.id.main), respuesta.mensaje, Snackbar.LENGTH_SHORT)
                        snackbar.setBackgroundTint(Color.parseColor("#F44336"))
                        snackbar.setTextColor(Color.WHITE)
                        snackbar.setAction("Cerrar") {
                            snackbar.dismiss() //
                        }
                        snackbar.show()
                        delay(1500)
                        textNoGastos.visibility = View.VISIBLE
                        listViewGastos.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        applicationContext,
                        "Error de conexión",
                        Toast.LENGTH_LONG
                    ).show()
                    textNoGastos.visibility = View.VISIBLE
                    listViewGastos.visibility = View.GONE
                }
            }
        }
    }

}
