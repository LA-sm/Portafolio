package com.appcrud

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import billsapppojos.DistribucionGasto
import billsapppojos.Gasto
import com.appcrud.adapters.DistribucionAdapter
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

class GastoActivity : AppCompatActivity() {

    // Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    //Recycler View donde se mostrarán las distribuciones del gasto
    private lateinit var recyclerView: RecyclerView

    //Variable para almecenar las distribuciones del gasto
    private var distribuconesDeGastos: MutableList<DistribucionGasto> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_gasto)

        //Obtención del gasto enviando en el intent
        val gasto: Gasto? = intent.getSerializableExtra("gasto") as? Gasto

        // Referencias a vistas del layout
        val descripcion = findViewById<TextView>(R.id.textDescripcion)
        val textFecha = findViewById<TextView>(R.id.textFecha)
        val avatarIcon = findViewById<TextView>(R.id.avatarIcon)
        val participanteAlias = findViewById<TextView>(R.id.participanteAlias)
        val textImorteTotal = findViewById<TextView>(R.id.textImporteTotal)
        recyclerView = findViewById<RecyclerView>(R.id.recyclerDistribuciones)
        val botonVolver = findViewById<ImageButton>(R.id.botonVolver)

        //Inicializar las variables con los datos del gasto
        descripcion.text = gasto?.descripcion
        avatarIcon.text = gasto?.participantePagador?.alias?.trim()?.firstOrNull()?.uppercase()
        participanteAlias.text = gasto?.participantePagador?.alias
        textImorteTotal.text = gasto?.importeTotal.toString() + " €"

        //Formatear fecha
        val formato = SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("es", "ES"))
        textFecha.text = gasto?.fecha?.let { formato.format(it).replaceFirstChar { c -> c.uppercase() } }

        val azul = ContextCompat.getColor(this, R.color.primary_light_blue)
        avatarIcon.background.setTint(azul)

        //Cargamos las distribuciones del gasto
        cargarDistribuciones(gasto?.gastoId)

        //Volvemos a GastosActivity
        botonVolver.setOnClickListener {
            val intent = Intent(this, GastosActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    //Método para mostrar mensaje de error
    private fun showError(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }

    //Método para cargar las distribuciones del gasto
    private fun cargarDistribuciones(gastoId: Int?) {

        //Creamos la petición de buscar distribuciones por gasto y la enviamos al servidor de forma asíncrona
        val peticion = Peticion(Peticion.TipoOperacion.BUSCAR_DISTRIBUCION_POR_GASTO, gastoId)
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticion)
                withContext(Dispatchers.Main) {
                    if (respuesta.isExito) {
                        distribuconesDeGastos = respuesta.listaDistribucionGasto

                        recyclerView.layoutManager = LinearLayoutManager(this@GastoActivity)

                        //Inicializamos el adaptador del recyclerView con las distribuciones obtenidas
                        recyclerView.adapter = DistribucionAdapter(distribuconesDeGastos)

                    } else {
                        showError("No se pudo cargar la distribución del gasto")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Error en la conexión")
                }
            }
        }
    }
}
