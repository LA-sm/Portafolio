package com.appcrud

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.tabs.TabLayout
import android.view.animation.OvershootInterpolator
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import billsapppojos.DistribucionGasto
import billsapppojos.Gasto
import com.appcrud.adapters.TransaccionesAdapter
import com.appcrud.apoyo.Balance
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ReembolsosActivity : AppCompatActivity() {

    // Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    //Variable para el id del grupo
    private var grupoId: Int = 0

    //Variable para almecenar los gastos del grupo
    private lateinit var listaGastos: MutableList<Gasto>

    //Variable para almecenar las distribuciones de cada uno de los gastos
    private lateinit var listaDistribuciones: MutableList<DistribucionGasto>

    //Recycler View donde se mostrarán los reembolsos
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_reembolsos)

        //Recuperar grupoId y el nombre del grupo desde las preferencias
        val prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        grupoId = prefs.getInt("idGrupoActual", 0)
        val grupoNombre = prefs.getString("nombreGrupoActual", "")

        // Obtención de vistas
        val textNombreGrupo = findViewById<TextView>(R.id.textGrupos)
        val botonVolver = findViewById<ImageButton>(R.id.botonVolver)

        //Asignarle el nombre del grupo recuperado al textView
        textNombreGrupo.text = grupoNombre

        // Inicialización de TabLayout y la vista del indicador
        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        val indicator = findViewById<View>(R.id.animatedIndicator)
        recyclerView = findViewById(R.id.recyclerDistribuciones)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Configuración de pestañas del menú
        val tabGastos = tabLayout.newTab().setCustomView(createCustomTabView("Gastos"))
        val tabBalance = tabLayout.newTab().setCustomView(createCustomTabView("Deudas"))
        val tabSaldos = tabLayout.newTab().setCustomView(createCustomTabView("Saldos"))

        tabLayout.addTab(tabGastos)
        tabLayout.addTab(tabBalance)
        tabLayout.addTab(tabSaldos)

        tabLayout.selectTab(tabBalance) //Selecciona la pestaña balance por defecto

        // Ajusta el modo de las pestañas según cantidad
        if (tabLayout.tabCount > 2) {
            tabLayout.tabMode = TabLayout.MODE_SCROLLABLE
        } else {
            tabLayout.tabMode = TabLayout.MODE_FIXED
        }

        // Ajustar la posición y tamaño del indicador cuando la vista se ha cargado
        tabLayout.post {
            val selectedTab = tabLayout.getTabAt(tabLayout.selectedTabPosition)
            selectedTab?.view?.let { tabView ->
                val tabX = tabView.left + tabLayout.left
                indicator.x = tabX.toFloat() // Posición X del indicador
                indicator.layoutParams.width = tabView.width
                indicator.requestLayout()
            }
        }

        // Listener para cuando se selecciona un tab
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                val tabView = tab.view
                val tabX = tabView.left + tabLayout.left

                val customView = tab.customView
                customView?.findViewById<TextView>(R.id.tabText)?.setTextColor(getColor(R.color.naranja))

                // Animación suave con rebote para el indicador
                indicator.animate()
                    .x(tabX.toFloat()) // Animar el movimiento del indicador
                    .setDuration(300) // Duración de la animación
                    .setInterpolator(OvershootInterpolator(1.2f))  // Añadido el interpolador de rebote
                    .start()

                // Ajustar el tamaño del indicador
                indicator.layoutParams.width = tabView.width
                indicator.requestLayout()

                // Cambia de actividad según pestaña
                when (tab.position) {
                    0 -> {
                        startActivity(Intent(this@ReembolsosActivity, GastosActivity::class.java))
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        finish() }
                    1 -> { }
                    2 -> {
                        startActivity(Intent(this@ReembolsosActivity, SaldosActivity::class.java))
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        finish()
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                val customView = tab?.customView
                customView?.findViewById<TextView>(R.id.tabText)?.setTextColor(getColor(R.color.dark_gray))
            }
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        // Inicializa las listas de gastos y distribuciones
        listaGastos = mutableListOf()
        listaDistribuciones = mutableListOf()

        //Cragar gastos al iniciar
        cargarGastos()

        //Volver a GruposActivity
        botonVolver.setOnClickListener {
            val intent = Intent(this, GruposActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Crea una vista personalizada para cada pestaña
    private fun createCustomTabView(text: String): View {
        val view = LayoutInflater.from(this).inflate(R.layout.custom_tab, null)
        val textView = view.findViewById<TextView>(R.id.tabText)
        textView.text = text
        return view
    }

    //Carga gastos del servidor
    private fun cargarGastos() {

        //Enviamos la peticion de buscar gastos por grupo de forma asíncrona
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val respuesta = ClienteSocket(HOST, PUERTO)
                    .enviarPeticion(Peticion(Peticion.TipoOperacion.BUSCAR_GASTOS_POR_GRUPO, grupoId))

                withContext(Dispatchers.Main) {
                    if (respuesta.isExito) {
                        listaGastos.clear() // Limpiar lista antes de añadir
                        listaGastos.addAll(respuesta.listaGastos) //Cargamos los gastos a la lista

                        //Cargamos las distribuciones de cada uno de los gastos
                        cargarDistribuciones(listaGastos)
                    }
                }
            }catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        applicationContext,
                        "Error de conexión",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    //Cargamos las distribuciones del servidor
    private fun cargarDistribuciones(listaGastos: MutableList<Gasto>) {

        //Enviamos las peticiónes de buscar distribuciobes por gasto de forma asíncrona
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                var distribucionesTotales = mutableListOf<DistribucionGasto>()

                //Buscamos las distribuciones de cada gasto y las almacenamos en la lista distribucionesTotales
                listaGastos.forEachIndexed { index, gasto ->
                    val respuesta = ClienteSocket(HOST, PUERTO)
                        .enviarPeticion(Peticion(Peticion.TipoOperacion.BUSCAR_DISTRIBUCION_POR_GASTO, gasto.gastoId))

                    if (respuesta.isExito){
                        distribucionesTotales.addAll(respuesta.listaDistribucionGasto)
                    }
                }

                withContext(Dispatchers.Main) {
                    listaDistribuciones.clear()
                    listaDistribuciones.addAll(distribucionesTotales)

                    //Calculamos el balance por participante
                    calcularBalanceParticipantes()
                }
            }catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        applicationContext,
                        "Error de conexión",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    //Devuelve un mapa de balances donde está el balance de cada participante
    //que haya participado en algun gasto
    private fun calcularBalanceParticipantes() {
        val balancesMap = mutableMapOf<Int, Balance>()

        // Inicializar balances
        //Primero lo que deben
        listaDistribuciones.forEach { dist ->
            val id = dist.participante.participanteId
            val alias = dist.participante.alias

            val balance = balancesMap.getOrPut(id) {
                Balance(participanteId = id, alias = alias)
            }

            balance.debe += dist.cantidad
        }

        //Luego lo que han pagado
        listaGastos.forEach { gasto ->
            val pagadorId = gasto.participantePagador.participanteId
            val pagadorAlias = gasto.participantePagador.alias

            val balance = balancesMap.getOrPut(pagadorId) {
                Balance(participanteId = pagadorId, alias = pagadorAlias)
            }

            balance.pagado += gasto.importeTotal
        }

        // Ahora optimizar las transacciones
        val resultados = resolverDeudas(balancesMap.values.toList())

        //Mostrar mensaje si todo está saldado
        if (resultados.isEmpty()) {
            Toast.makeText(this, "Todos están saldados 🎉", Toast.LENGTH_SHORT).show()

            val textSaldado = findViewById<TextView>(R.id.textSaldado)
            textSaldado.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            val textSaldado = findViewById<TextView>(R.id.textSaldado)
            textSaldado.clearAnimation()
            textSaldado.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
            recyclerView.adapter = TransaccionesAdapter(resultados)
        }


    }

    //Método que devuelve una lista de que participante le debe a cual y cuanto
    private fun resolverDeudas(balances: List<Balance>): List<Triple<String, String, Double>> {
        val deudores = balances.filter { it.balance < 0 }.sortedBy { it.balance }.toMutableList()
        val acreedores = balances.filter { it.balance > 0 }.sortedByDescending { it.balance }.toMutableList()

        val transacciones = mutableListOf<Triple<String, String, Double>>()

        var i = 0
        var j = 0

        while (i < deudores.size && j < acreedores.size) {
            val deudor = deudores[i]
            val acreedor = acreedores[j]

            val deuda = -deudor.balance
            val credito = acreedor.balance

            val monto = minOf(deuda, credito)

            transacciones.add(Triple(deudor.alias, acreedor.alias, monto))

            deudor.pagado += monto
            acreedor.debe += monto

            if (deudor.balance >= 0) i++
            if (acreedor.balance <= 0) j++
        }

        return transacciones
    }

}

