package com.appcrud

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import billsapppojos.Usuario
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.appcrud.comunicacion.Respuesta
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.net.InetSocketAddress
import java.net.Socket

class CrearUsuarioActivity : AppCompatActivity() {

    //Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_crear_usuario)

        // TextInputLayouts
        val emailLayout    = findViewById<TextInputLayout>(R.id.emailInputLayout)
        val passLayout     = findViewById<TextInputLayout>(R.id.passwordInputLayout)
        val aliasLayout    = findViewById<TextInputLayout>(R.id.aliasInputLayout)
        val telefonoLayout = findViewById<TextInputLayout>(R.id.telefonoInputLayout)

        // EditTexts
        val editEmail    = findViewById<TextInputEditText>(R.id.editEmail)
        val editPass     = findViewById<TextInputEditText>(R.id.editPass)
        val editAlias    = findViewById<TextInputEditText>(R.id.editAlias)
        val editTelefono = findViewById<TextInputEditText>(R.id.editTelefono)

        //Botones
        val botonAceptar      = findViewById<Button>(R.id.botonAceptar)
        val botonVolver       = findViewById<Button>(R.id.botonVolver)

        // Prefs y alias actual
        val prefs  = getSharedPreferences("datos", Context.MODE_PRIVATE)
        val editor = prefs.edit()

        // --- Validación en tiempo real ---

        // Email
        editEmail.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val email = s.toString().trim()
                emailLayout.error = when {
                    email.isBlank() -> "El email no puede estar vacío"
                    !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Introduce un email válido"
                    else -> null
                }
                emailLayout.isErrorEnabled = emailLayout.error != null
            }
        })

        // Tamaño máximo de la contraseña
        editPass.filters = arrayOf(InputFilter.LengthFilter(20))

        //Validación en tiempo real de la contraseña
        editPass.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val pass = s.toString()
                when {
                    pass.isBlank() -> {
                        passLayout.error = "La contraseña no puede estar vacía"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    pass.length < 6 -> {
                        passLayout.error = "La contraseña debe tener al menos 6 caracteres"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    pass.length > 20 -> {
                        passLayout.error = "La contraseña no puede tener más de 20 caracteres"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    !pass.any { it.isUpperCase() } -> {
                        passLayout.error = "La contraseña debe tener al menos una letra mayúscula"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    !pass.any { it.isLowerCase() } -> {
                        passLayout.error = "La contraseña debe tener al menos una letra minúscula"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    !pass.any { it.isDigit() } -> {
                        passLayout.error = "La contraseña debe tener al menos un número"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    else -> {
                        passLayout.error = null
                        passLayout.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
                        passLayout.isErrorEnabled = passLayout.error != null
                    }
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Máximo 30 caracteres al campo alias
        editAlias.filters = arrayOf(InputFilter.LengthFilter(30))

        //Validación en tiempo real del alias
        editAlias.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val alias = s.toString()
                aliasLayout.error = when {
                    alias.isBlank() -> "El alias no puede estar vacío"
                    !alias.firstOrNull()?.isLetter().orFalse() -> "El alias debe empezar con letra"
                    alias.length > 30 -> "Alias máximo 30 caracteres"
                    alias.length < 2 -> "Alias mínimo 2 caracteres"
                    else -> null
                }
                aliasLayout.isErrorEnabled = aliasLayout.error != null
            }
        })

        //Tamaño máximo del teléfono 9 caracteres
        editTelefono.filters = arrayOf(InputFilter.LengthFilter(9))

        // Validación en tiempo real del teléfono
        editTelefono.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val tel = s.toString()
                telefonoLayout.error = when {
                    tel.isBlank() -> "El teléfono no puede estar vacío"
                    tel.length != 9 -> "El teléfono debe tener 9 dígitos"
                    !tel.all { it.isDigit() } -> "Solo dígitos permitidos"
                    else -> null
                }
                telefonoLayout.isErrorEnabled = telefonoLayout.error != null
            }
        })

        // Lógica de creación de usuario
        botonAceptar.setOnClickListener {
            // 1) Validar errores en los TextInputLayout
            val camposConError = listOf(aliasLayout to editAlias, telefonoLayout to editTelefono,
                                        emailLayout to editEmail, passLayout to editPass)
                .filter { (layout, _) -> layout.error != null }

            if (camposConError.isNotEmpty()) {
                camposConError.forEach { (_, campo) ->
                    shakeView(campo)
                    vibratePhone()
                }
                return@setOnClickListener
            }

            // 2) Comprobar campos vacíos
            val campos = listOf(editEmail, editPass, editAlias, editTelefono)
            if (campos.any { it.text.toString().isBlank() }) {
                campos.filter { it.text.toString().isBlank() }.forEach {
                    shakeView(it)
                    vibratePhone()
                }
                return@setOnClickListener
            }

            // Si llegamos aquí,todo esta OK

            //Creamos un usuario con los datos insertados
            val usuario = Usuario(
                editAlias.text.toString().trim(),
                editEmail.text.toString().trim(),
                editPass.text.toString(),
                editTelefono.text.toString(),
                0
            )

            //Hacemos la petición de forma asíncrona al servidor para crear usuario
            val peticion = Peticion(Peticion.TipoOperacion.CREATE_USER, usuario)
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticion)
                    withContext(Dispatchers.Main) {

                        // Determinamos el color del Snackbar según el resultado
                        val colorFondo = if (respuesta.isExito) {
                            Color.parseColor("#4FC3F7")
                        } else {
                            Color.parseColor("#F44336")
                        }

                        // Creamos y mostramos el Snackbar
                        val snackbar = Snackbar.make(findViewById(R.id.main), respuesta.mensaje, Snackbar.LENGTH_SHORT)
                        snackbar.setBackgroundTint(colorFondo)
                        snackbar.setTextColor(Color.WHITE) // Texto blanco para buen contraste
                        snackbar.setAction("Cerrar") {
                            snackbar.dismiss() // El botón "Cerrar" para que el usuario pueda cerrar el Snackbar
                        }
                        snackbar.show()

                        //Si fue un éxito la creación del usuario navegamos a la pantalla de GruposActivity
                        if (respuesta.isExito) {
                            delay(1500)
                            editor.putString("usuarioActual", respuesta.usuario.email)
                            editor.putString("passwordActual", respuesta.usuario.password)
                            editor.putInt("idActual", respuesta.usuario.userId)
                            editor.putString("aliasActual", respuesta.usuario.alias)
                            editor.putString("telefonoActual", respuesta.usuario.telefono)
                            editor.apply()
                            startActivity(Intent(this@CrearUsuarioActivity, GruposActivity::class.java))
                            finish()
                        }
                    }
                } catch (e: IOException) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@CrearUsuarioActivity, "Error de red", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        // Volvemos a MainActivity
        botonVolver.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(sys.left, sys.top, sys.right, sys.bottom)
            insets
        }
    }

    private fun Boolean?.orFalse() = this ?: false

    // Vibración corta para feedback táctil
    private fun vibratePhone() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(150)
        }
    }

    // Animación shake para vistas (indicar error)
    private fun shakeView(view: View) {
        val anim = TranslateAnimation(0f, 10f, 0f, 0f).apply {
            duration = 100
            repeatMode = Animation.REVERSE
            repeatCount = 3
        }
        view.startAnimation(anim)
    }
}
