package com.appcrud

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.Button
import android.widget.ImageButton
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import billsapppojos.Usuario
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class Perfil : AppCompatActivity() {

    // Dirección IP y puerto del servidor al que se conecta la app
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    // Preferencias para almacenar datos del usuario
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var editor: android.content.SharedPreferences.Editor

    // Variables que almacenan los datos actuales del usuario
    private var idUserActual: Int = 0
    private var usuarioActual: String? = null
    private var passwordActual: String? = null
    private var aliasActual: String? = null
    private var telefonoActual: String? = null
    private var modoOscuro: Boolean = false

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        // Inicialización de preferencias y recuperación de datos guardados
        prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        editor = prefs.edit()
        modoOscuro = prefs.getBoolean("modoOscuro", false)
        idUserActual = prefs.getInt("idActual", 0)
        usuarioActual = prefs.getString("usuarioActual", null)
        passwordActual = prefs.getString("passwordActual", null)
        aliasActual = prefs.getString("aliasActual", null)
        telefonoActual = prefs.getString("telefonoActual", null)

        // Referencias a componentes del layout
        val aliasLayout    = findViewById<TextInputLayout>(R.id.aliasInputLayout)
        val telefonoLayout = findViewById<TextInputLayout>(R.id.telefonoInputLayout)
        val editAlias      = findViewById<TextInputEditText>(R.id.editAlias)
        val editTelefono   = findViewById<TextInputEditText>(R.id.editTelefono)
        val textEmailActual = findViewById<TextView>(R.id.textEmailActual)
        val botonEliminar     = findViewById<Button>(R.id.botonEliminar)
        val botonCerrarSesion = findViewById<Button>(R.id.botonCerrarSesion)
        val botonVolver       = findViewById<ImageButton>(R.id.botonVolver)
        val botonModificPerfil = findViewById<Button>(R.id.botonModificPerfil)
        val switch            = findViewById<Switch>(R.id.switch1)

        // Establece el estado del switch de modo oscuro
        switch.isChecked = modoOscuro
        actualizarColoresSwitch(switch, modoOscuro)

        // Muestra el correo actual del usuario
        prefs.getString("usuarioActual", null)?.let {
            textEmailActual.text = it
        }

        // Carga los datos del usuario en los campos de texto
        editAlias.setText(aliasActual)
        editTelefono.setText(telefonoActual)

        // Filtro para limitar el tamaño del alias a 30 caracteres
        editAlias.filters = arrayOf(InputFilter.LengthFilter(30))

        // Validaciones en tiempo real del alias ingresado
        editAlias.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val alias = s.toString()
                aliasLayout.error = when {
                    alias.isBlank() -> "El alias no puede estar vacío"
                    !alias.firstOrNull()?.isLetter().orFalse() -> "El alias debe empezar con una letra"
                    alias.length < 2 -> "Alias mínimo 2 caracteres"
                    alias.length > 30 -> "Alias máximo 30 caracteres"
                    else -> null
                }
            }
        })

        // Limita el campo teléfono a 9 dígitos
        editTelefono.filters = arrayOf(InputFilter.LengthFilter(9))

        // Validaciones del campo teléfono
        editTelefono.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                val tel = s.toString()
                telefonoLayout.error = when {
                    tel.isBlank() -> "El teléfono no puede estar vacío"
                    tel.length != 9 -> "El teléfono debe tener 9 dígitos"
                    !tel.all { it.isDigit() } -> "Solo dígitos permitidos"
                    else -> null
                }
            }
        })

        // Desactiva el botón de cerrar sesión si no hay usuario cargado
        if (usuarioActual.isNullOrBlank() || passwordActual.isNullOrBlank()) {
            botonCerrarSesion.isEnabled = false
            botonCerrarSesion.alpha = 0.5f
        } else {
            botonCerrarSesion.isEnabled = true
            botonCerrarSesion.alpha = 1f
        }

        // Inicialmente desactiva el botón de modificar perfil
        botonModificPerfil.isEnabled = false
        botonModificPerfil.alpha = 0.5f

        // Observa cambios en los campos para activar el botón de modificar si hay cambios
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val aliasModificado = editAlias.text.toString().trim() != aliasActual
                val telefonoModificado = editTelefono.text.toString().trim() != telefonoActual
                val hayCambios = aliasModificado || telefonoModificado

                botonModificPerfil.isEnabled = hayCambios
                botonModificPerfil.alpha = if (hayCambios) 1.0f else 0.5f
            }
        }

        // Agrega el watcher a los campos
        editAlias.addTextChangedListener(textWatcher)
        editTelefono.addTextChangedListener(textWatcher)

        // Acción del botón para modificar perfil
        botonModificPerfil.setOnClickListener {
            // Verifica si hay errores en los campos
            val camposConError = listOf(aliasLayout to editAlias, telefonoLayout to editTelefono)
                .filter { (layout, _) -> layout.error != null }

            if (camposConError.isNotEmpty()) {
                // Si hay errores, sacude los campos y vibra
                camposConError.forEach { (_, campo) ->
                    shakeView(campo)
                    vibratePhone()
                }
                return@setOnClickListener
            }

            // Verifica que no haya campos vacíos
            val campos = listOf(editAlias, editTelefono)
            if (campos.any { it.text.toString().isBlank() }) {
                campos.filter { it.text.toString().isBlank() }.forEach {
                    shakeView(it)
                    vibratePhone()
                }
                return@setOnClickListener
            }

            // Crea el nuevo objeto Usuario
            val usuario = Usuario(
                editAlias.text.toString().trim(),
                usuarioActual,
                passwordActual,
                editTelefono.text.toString(),
                idUserActual
            )

            // Muestra diálogo de confirmación
            MaterialAlertDialogBuilder(this, R.style.CustomAlertDialog)
                .setTitle("¡Confirmación!")
                .setMessage("¿Estás seguro que quieres modificar el usuario $aliasActual?")
                .setIcon(R.drawable.ic_warning)
                .setPositiveButton("Sí") { dialog, _ ->
                    actualizarUsuario(usuario)
                    dialog.dismiss()
                }
                .setNegativeButton("Cancelar") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }

        // Acción del botón eliminar usuario
        botonEliminar.setOnClickListener {
            mostrarDialogoAdvertencia()
        }

        // Acción del botón cerrar sesión
        botonCerrarSesion.setOnClickListener {
            val modoOscuro = prefs.getBoolean("modoOscuro", false)
            editor.clear()
            editor.putBoolean("modoOscuro", modoOscuro)
            editor.apply()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Vuelve a la pantalla de grupos
        botonVolver.setOnClickListener {
            startActivity(Intent(this, GruposActivity::class.java))
            finish()
        }

        // Acción del switch para modo oscuro
        switch.setOnCheckedChangeListener { _, isChecked ->
            editor.putBoolean("modoOscuro", isChecked).apply()

            val fadeOut = android.view.animation.AlphaAnimation(1f, 0f).apply {
                duration = 300
                fillAfter = true
            }

            val fadeIn = android.view.animation.AlphaAnimation(0f, 1f).apply {
                duration = 300
                fillAfter = true
            }

            val rootView = findViewById<View>(R.id.main)
            rootView.startAnimation(fadeOut)

            rootView.postDelayed({
                AppCompatDelegate.setDefaultNightMode(
                    if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
                )
                rootView.startAnimation(fadeIn)
            }, 300)
        }

        // Ajusta el padding del layout según los insets del sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Cambia los colores del switch según si está activado o no
    private fun actualizarColoresSwitch(switch: Switch, isChecked: Boolean) {
        if (isChecked) {
            switch.thumbTintList = ColorStateList.valueOf(Color.parseColor("#FF5722"))
            switch.trackTintList = ColorStateList.valueOf(Color.parseColor("#4FC3F7"))
        } else {
            switch.thumbTintList = ColorStateList.valueOf(Color.parseColor("#969699"))
            switch.trackTintList = ColorStateList.valueOf(Color.parseColor("#5D5C5C"))
        }
    }

    // Muestra diálogo de advertencia para eliminar usuario
    private fun mostrarDialogoAdvertencia() {
        MaterialAlertDialogBuilder(this, R.style.CustomAlertDialog)
            .setTitle("¡Confirmación!")
            .setMessage("¿Estás seguro que querés eliminar el usuario ${aliasActual}?")
            .setIcon(R.drawable.ic_warning)
            .setPositiveButton("Sí") { dialog, _ ->
                eliminarUsuario()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    // Elimina usuario y vuelve al login
    private fun eliminarUsuario() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val respuesta = ClienteSocket(HOST, PUERTO)
                    .enviarPeticion(Peticion(Peticion.TipoOperacion.DELETE_USER, idUserActual))

                withContext(Dispatchers.Main) {
                    val colorFondo = if (respuesta.isExito) Color.parseColor("#4FC3F7") else Color.parseColor("#F44336")
                    Snackbar.make(findViewById(R.id.main), respuesta.mensaje, Snackbar.LENGTH_SHORT)
                        .apply {
                            setBackgroundTint(colorFondo)
                            setTextColor(Color.WHITE)
                            setAction("Cerrar") { dismiss() }
                            show()
                        }

                    if (respuesta.isExito) {
                        delay(1500)
                        val modoOscuro = prefs.getBoolean("modoOscuro", false)
                        editor.clear()
                        editor.putBoolean("modoOscuro", modoOscuro)
                        editor.apply()

                        startActivity(Intent(this@Perfil, MainActivity::class.java))
                        finish()
                    }
                }
            } catch (e: IOException) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@Perfil, "Error de red: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Actualiza el usuario en el servidor y guarda los cambios localmente
    private fun actualizarUsuario(usuario: Usuario) {
        val peticion = Peticion(Peticion.TipoOperacion.UPDATE_USER, usuario)

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticion)
                withContext(Dispatchers.Main) {
                    val colorFondo = if (respuesta.isExito) Color.parseColor("#4FC3F7") else Color.parseColor("#F44336")
                    Snackbar.make(findViewById(R.id.main), respuesta.mensaje, Snackbar.LENGTH_SHORT)
                        .apply {
                            setBackgroundTint(colorFondo)
                            setTextColor(Color.WHITE)
                            setAction("Cerrar") { dismiss() }
                            show()
                        }

                    if (respuesta.isExito) {
                        delay(1500)
                        editor.putString("aliasActual", usuario.alias)
                        editor.putString("telefonoActual", usuario.telefono)
                        editor.apply()

                        startActivity(Intent(this@Perfil, GruposActivity::class.java))
                        finish()
                    }
                }
            } catch (e: IOException) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@Perfil, "Error de red: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Vibra el dispositivo
    private fun vibratePhone() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(150)
        }
    }

    // Anima una vista con efecto de "sacudida"
    private fun shakeView(view: View) {
        val anim = TranslateAnimation(0f, 10f, 0f, 0f).apply {
            duration = 100
            repeatMode = Animation.REVERSE
            repeatCount = 3
        }
        view.startAnimation(anim)
    }
}

// Función de extensión para evitar nulos en booleanos
fun Boolean?.orFalse() = this ?: false
