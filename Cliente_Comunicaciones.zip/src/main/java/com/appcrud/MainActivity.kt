package com.appcrud

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class MainActivity : AppCompatActivity() {

    //Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    //Declaración de variables en el contexto de clase para usarlas en otros métodos
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var editor: android.content.SharedPreferences.Editor

    private var idUserActual: Int = 0
    private var usuarioActual: String? = null
    private var passwordActual: String? = null
    private var aliasActual: String? = null
    private var telefonoActual: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        // Inicializar SharedPreferences y obtener el valor de modoOscuro antes de llamar a super.onCreate
        prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        editor = prefs.edit()
        val modoOscuro = prefs.getBoolean("modoOscuro", false)

        // Aplicar el modo oscuro o claro según el valor almacenado
        if (modoOscuro) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        //Inicializamos vistas
        idUserActual = prefs.getInt("idActual", 0)
        usuarioActual = prefs.getString("usuarioActual", null)
        passwordActual = prefs.getString("passwordActual", null)
        aliasActual = prefs.getString("aliasActual", null)
        telefonoActual = prefs.getString("telefonoActual", null)

        // Definimos otras vistas
        val editEmail = findViewById<EditText>(R.id.editEmail)
        val emailLayout = findViewById<TextInputLayout>(R.id.emailInputLayout)
        val editPass = findViewById<EditText>(R.id.editPass)
        val passLayout = findViewById<TextInputLayout>(R.id.passwordInputLayout)
        val botonAceptar = findViewById<Button>(R.id.botonAceptar)
        val botonCrearUsuario = findViewById<Button>(R.id.botonCrearUsuario)

        var credencialesIncorrectasMostradas = false

        //Validación en tiempo real del email
        editEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (credencialesIncorrectasMostradas) {
                    emailLayout.error = null
                    passLayout.error = null
                    emailLayout.isErrorEnabled = false
                    passLayout.isErrorEnabled = false
                    credencialesIncorrectasMostradas = false
                }

                val email = s.toString().trim()
                emailLayout.error = when {
                    email.isBlank() -> "El email no puede estar vacío"
                    !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Introduce un email válido"
                    else -> null
                }
                emailLayout.isErrorEnabled = emailLayout.error != null
                passLayout.isErrorEnabled = passLayout.error != null
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        //Tamaño máximo para la contraseña
        editPass.filters = arrayOf(InputFilter.LengthFilter(20))

        //Validación en tiempo real de la contraseña
        editPass.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (credencialesIncorrectasMostradas) {
                    emailLayout.error = null
                    passLayout.error = null
                    emailLayout.isErrorEnabled = false
                    passLayout.isErrorEnabled = false
                    credencialesIncorrectasMostradas = false
                }

                val pass = s.toString()
                when {
                    pass.isBlank() -> {
                        passLayout.error = "La contraseña no puede estar vacía"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    pass.length < 6 -> {
                        passLayout.error = "La contraseña debe tener al menos 6 caracteres"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    pass.length > 20 -> {
                        passLayout.error = "La contraseña no puede tener más de 20 caracteres"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    !pass.any { it.isUpperCase() } -> {
                        passLayout.error = "Debe tener una letra mayúscula"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    !pass.any { it.isLowerCase() } -> {
                        passLayout.error = "Debe tener una letra minúscula"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    !pass.any { it.isDigit() } -> {
                        passLayout.error = "Debe tener un número"
                        passLayout.endIconMode = TextInputLayout.END_ICON_NONE
                    }
                    else -> {
                        passLayout.error = null
                        passLayout.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
                        passLayout.isErrorEnabled = passLayout.error != null
                        emailLayout.isErrorEnabled = emailLayout.error != null
                    }
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        //Lógica de inicio de sesión
        botonAceptar.setOnClickListener {
            val email = editEmail.text.toString().trim()
            val password = editPass.text.toString()

            //Antes validamos que no hayan errones en los campos y que no esten vacios
            val camposConError = listOf(emailLayout to editEmail, passLayout to editPass)
                .filter { (layout, _) -> layout.error != null }

            if (camposConError.isNotEmpty()) {
                camposConError.forEach { (_, campo) ->
                    shakeView(campo)
                    vibratePhone()
                }
                return@setOnClickListener
            }

            val campos = listOf(editEmail, editPass)
            if (campos.any { it.text.toString().isBlank() }) {
                campos.filter { it.text.toString().isBlank() }.forEach {
                    shakeView(it)
                    vibratePhone()
                }
                return@setOnClickListener
            }

            //Enviamos la peticón de login al servidor para comprobar que el usuario existe en la BD
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(
                        Peticion(Peticion.TipoOperacion.LOGIN, email, password)
                    )
                    withContext(Dispatchers.Main) {

                        // Determinamos el color del Snackbar según el resultado
                        val colorFondo = if (respuesta.isExito) {
                            Color.parseColor("#4FC3F7")
                        } else {
                            Color.parseColor("#F44336")
                        }

                        // Creamos y mostramos el Snackbar
                        val snackbar = Snackbar.make(findViewById(R.id.main), respuesta.mensaje, Snackbar.LENGTH_SHORT)
                        snackbar.setBackgroundTint(colorFondo)
                        snackbar.setTextColor(Color.WHITE)
                        snackbar.setAction("Cerrar") {
                            snackbar.dismiss()
                        }
                        snackbar.show()

                        //Si el login fue exitoso nos redirecciona a la pantalla GruposActivity
                        if (respuesta.isExito) {
                            delay(1500)
                            editor.putString("usuarioActual", respuesta.usuario.email)
                            editor.putString("passwordActual", respuesta.usuario.password)
                            editor.putInt("idActual", respuesta.usuario.userId)
                            editor.putString("aliasActual", respuesta.usuario.alias)
                            editor.putString("telefonoActual", respuesta.usuario.telefono)
                            editor.apply()
                            startActivity(Intent(this@MainActivity, GruposActivity::class.java))
                            finish()
                        }else{
                            //Si no es exitoso se lo hacemos saber al usuario con un mensaje, un efecto visual sobre el campo y vibración
                            credencialesIncorrectasMostradas = true
                            emailLayout.error = "Credenciales incorrectas"
                            passLayout.error = "Credenciales incorrectas"
                            emailLayout.isErrorEnabled = true
                            passLayout.isErrorEnabled = true

                            shakeView(editEmail)
                            shakeView(editPass)
                            vibratePhone()
                        }
                    }
                } catch (e: IOException) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, "Error de red: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        //Ir a la pantalla CrearUsuarioActivity
        botonCrearUsuario.setOnClickListener {
            val intent = Intent(this, CrearUsuarioActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(sys.left, sys.top, sys.right, sys.bottom)
            insets
        }
    }

    // Vibración corta para feedback táctil
    private fun vibratePhone() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(150)
        }
    }

    // Animación shake para vistas (indicar error)
    private fun shakeView(view: View) {
        val anim = TranslateAnimation(0f, 10f, 0f, 0f).apply {
            duration = 100
            repeatMode = Animation.REVERSE
            repeatCount = 3
        }
        view.startAnimation(anim)
    }
}

