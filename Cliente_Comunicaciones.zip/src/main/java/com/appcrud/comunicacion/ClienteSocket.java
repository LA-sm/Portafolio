package com.appcrud.comunicacion;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClienteSocket {

    //Declaramos el host, el puerto y el construtor

    private String host;
    private int puerto;

    public ClienteSocket(String host, int puerto){
        this.host = host;
        this.puerto = puerto;
    }

    //Creamos un metodo enviarPeticion
    public Respuesta enviarPeticion(Peticion peticion){
        Socket socket = null;
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        Respuesta respuesta = null;

        try {
            socket = new Socket(host, puerto);
            oos = new ObjectOutputStream(socket.getOutputStream());
            ois = new ObjectInputStream(socket.getInputStream());

            //Enviamos la peticion
            oos.writeObject(peticion);
            oos.flush();

            //Recibimos las respuesta
            respuesta = (Respuesta) ois.readObject();

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                if (oos != null) oos.close();
                if (ois != null) ois.close();
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace(); // Solo imprime el error, no lances una RuntimeException
            }
        }

        return respuesta;
    }

}
