package com.appcrud.comunicacion;

import java.io.Serializable;
import java.util.List;

import billsapppojos.DistribucionGasto;
import billsapppojos.Gasto;
import billsapppojos.Grupo;
import billsapppojos.Participante;
import billsapppojos.Usuario;

public class Respuesta implements Serializable {

	private boolean exito;
	private String mensaje;
	private Usuario usuario;
	private Grupo grupo;
	private Gasto gasto;
	private List<Usuario> usuarios;
	private List<Grupo> listaGrupos;
	private List<Gasto> listaGastos;
	private List<Participante> listaParticipantes;
	private List<DistribucionGasto> listaDistribucionGasto;
	private Integer registrosAfectados;


	public Respuesta() {
	}


	public Respuesta(boolean exito, Integer registrosAfectados, String mensaje, Usuario usuario, Grupo grupo, Gasto gasto, List<Usuario> usuarios,
					 List<Grupo> listaGrupos, List<Gasto> listaGastos, List<Participante> listaParticipantes, List<DistribucionGasto> listaDistribucionGasto) {
		super();
		this.exito = exito;
		this.mensaje = mensaje;
		this.usuario = usuario;
		this.grupo = grupo;
		this.gasto = gasto;
		this.usuarios = usuarios;
		this.registrosAfectados = registrosAfectados;
		this.listaGrupos = listaGrupos;
		this.listaGastos = listaGastos;
		this.listaParticipantes = listaParticipantes;
		this.listaDistribucionGasto = listaDistribucionGasto;
	}


	public boolean isExito() {
		return exito;
	}


	public void setExito(boolean exito) {
		this.exito = exito;
	}


	public String getMensaje() {
		return mensaje;
	}


	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}


	public Usuario getUsuario() {
		return usuario;
	}


	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}


	public List<Usuario> getUsuarios() {
		return usuarios;
	}


	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}


	public Integer getRegistrosAfectados() {
		return registrosAfectados;
	}


	public void setRegistrosAfectados(Integer registrosAfectados) {
		this.registrosAfectados = registrosAfectados;
	}


	public List<Grupo> getListaGrupos() {
		return listaGrupos;
	}


	public void setListaGrupos(List<Grupo> listaGrupos) {
		this.listaGrupos = listaGrupos;
	}


	public List<Gasto> getListaGastos() {
		return listaGastos;
	}


	public void setListaGastos(List<Gasto> listaGastos) {
		this.listaGastos = listaGastos;
	}


	public List<DistribucionGasto> getListaDistribucionGasto() {
		return listaDistribucionGasto;
	}


	public void setListaDistribucionGasto(List<DistribucionGasto> listaDistribucionGasto) {
		this.listaDistribucionGasto = listaDistribucionGasto;
	}


	public Grupo getGrupo() {
		return grupo;
	}


	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}


	public List<Participante> getListaParticipantes() {
		return listaParticipantes;
	}


	public void setListaParticipantes(List<Participante> listaParticipantes) {
		this.listaParticipantes = listaParticipantes;
	}


	public Gasto getGasto() {
		return gasto;
	}


	public void setGasto(Gasto gasto) {
		this.gasto = gasto;
	}



}
