package com.appcrud

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import billsapppojos.Grupo
import com.appcrud.adapters.CustomAdapter
import com.appcrud.comunicacion.ClienteSocket
import com.appcrud.comunicacion.Peticion
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GruposActivity : AppCompatActivity() {

    // Dirección IP y puerto del servidor
    private val HOST = "192.168.43.161"
    private val PUERTO = 5000

    private var idUserActual:Int = 0
    private lateinit var listaMutable: MutableList<Grupo>
    private lateinit var adapter: CustomAdapter
    private lateinit var textNoGrupos: TextView
    private lateinit var listViewGrupos: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()

        // Configuración del modo oscuro
        val prefs = getSharedPreferences("datos", Context.MODE_PRIVATE)
        val modoOscuro = prefs.getBoolean("modoOscuro", false)
        val editor = prefs.edit()

        AppCompatDelegate.setDefaultNightMode(
            if (modoOscuro) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )

        setContentView(R.layout.activity_grupos)

        // ID del usuario actual obtenido de SharedPreferences
        idUserActual = prefs.getInt("idActual", 0)

        // Inicialización de vistas
        val btnAnadirGrupo = findViewById<ImageButton>(R.id.botonAnadirGrupo)
        val botonPerfil = findViewById<ImageButton>(R.id.botonPerfil)
        val botonAyuda = findViewById<ImageButton>(R.id.botonAyuda)
        listViewGrupos = findViewById(R.id.listViewGrupos)
        textNoGrupos = findViewById(R.id.textNoGrupos)

        // Lista que se usará como fuente de datos para el adaptador
        listaMutable = mutableListOf()
        adapter = CustomAdapter(this, listaMutable)
        listViewGrupos.adapter = adapter

        //Cargamos los grupos de la base de datos
        cargarGrupos()

        // Al hacer clic en un grupo, guardar su información en SharedPreferences y abrir GastosActivity
        listViewGrupos.setOnItemClickListener { _, _, position, _ ->
            editor.putString("nombreGrupoActual", listaMutable[position].nombre)
            editor.putInt("idGrupoActual", listaMutable[position].grupoId)
            editor.putString("fechaGrupo", listaMutable[position].fechaCreacion.toString())
            editor.apply()

            val intent = Intent(this, GastosActivity::class.java)
            startActivity(intent)
        }

        // Al hacer clic prolongado, mostrar BottomSheet con opciones de editar/eliminar
        listViewGrupos.setOnItemLongClickListener { _, _, position, _ ->
            val bottomSheetView = LayoutInflater.from(this)
                .inflate(R.layout.layout_bottom_sheet_grupo, null)
            val bottomSheetDialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
            bottomSheetDialog.setContentView(bottomSheetView)

            val btnEditar = bottomSheetView.findViewById<LinearLayout>(R.id.btnEditar)
            val btnEliminar = bottomSheetView.findViewById<LinearLayout>(R.id.btnEliminar)

            //Redirigir a pantalla ModificarGrupoActivity para modificar el grupo seleccionado
            btnEditar.setOnClickListener {
                bottomSheetDialog.dismiss()
                val intent = Intent(this, ModificarGrupoActivity::class.java).apply {
                    putExtra("grupoId", listaMutable[position].grupoId)
                    putExtra("nombre", listaMutable[position].nombre)
                    putExtra("grupo", listaMutable[position])
                }
                startActivity(intent)
            }

            //Eliminar el grupo seleccionado
            btnEliminar.setOnClickListener {
                bottomSheetDialog.dismiss()
                MaterialAlertDialogBuilder(this, R.style.CustomAlertDialog)
                    .setTitle("¡Confirmación!")
                    .setMessage("¿Seguro que deseas eliminar el grupo \"${listaMutable[position].nombre}\"?")
                    .setIcon(R.drawable.ic_warning)
                    .setPositiveButton("Sí") { dialog, _ ->
                        val peticion = Peticion(Peticion.TipoOperacion.DELETE_GRUPO, listaMutable[position].grupoId)
                        lifecycleScope.launch(Dispatchers.IO) {
                            val respuesta = ClienteSocket(HOST, PUERTO).enviarPeticion(peticion)

                            val colorFondo = if (respuesta.isExito) "#4FC3F7" else "#F44336"

                            withContext(Dispatchers.Main) {
                                if (respuesta.isExito) {
                                    listaMutable.removeAt(position)
                                    adapter.notifyDataSetChanged()
                                }

                                // Mostrar mensaje si no quedan grupos
                                textNoGrupos.visibility =
                                    if (listaMutable.isEmpty()) View.VISIBLE else View.GONE
                                listViewGrupos.visibility =
                                    if (listaMutable.isEmpty()) View.GONE else View.VISIBLE

                                mostrarSnackbar(respuesta.mensaje, colorFondo)
                                delay(1500)
                            }
                        }
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
                    .show()
            }

            bottomSheetDialog.show()
            true
        }

        // Navegar a pantalla de perfil
        botonPerfil.setOnClickListener {
            startActivity(Intent(this, Perfil::class.java))
            finish()
        }

        // Navegar a pantalla de creación de grupo
        btnAnadirGrupo.setOnClickListener {
            val intent = Intent(this, CrearGrupoActivity::class.java)
            startActivity(intent);
        }

        botonAyuda.setOnClickListener{
            val intent = Intent(this, AyudaActivity::class.java)
            startActivity(intent);
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun onResume() {
        super.onResume()
        cargarGrupos()
    }

    // Muestra un snackbar con el mensaje y color especificado
    private fun mostrarSnackbar(mensaje: String, colorHex: String) {
        val snackbar = Snackbar.make(findViewById(R.id.main), mensaje, Snackbar.LENGTH_SHORT)
        snackbar.setBackgroundTint(Color.parseColor(colorHex))
        snackbar.setTextColor(Color.WHITE)
        snackbar.setAction("Cerrar") { snackbar.dismiss() }
        snackbar.show()
    }

    // Llamada asincrónica para obtener los grupos del usuario
    private fun cargarGrupos(){
        // Crear petición para obtener los grupos del usuario
        val peticionGrupos = Peticion(Peticion.TipoOperacion.BUSCAR_GRUPOS_POR_USUARIO, idUserActual)
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val socket = ClienteSocket(HOST, PUERTO)
                val respuesta = socket.enviarPeticion(peticionGrupos)

                withContext(Dispatchers.Main) {
                    if (respuesta.isExito) {
                        val gruposOrdenados = respuesta.listaGrupos
                            .sortedWith(
                                compareByDescending<Grupo> { it.fechaCreacion }
                                    .thenByDescending { it.grupoId }
                            )

                        listaMutable.clear()
                        listaMutable.addAll(gruposOrdenados)
                        adapter.notifyDataSetChanged()

                        // Mostrar mensaje si no hay grupos
                        textNoGrupos.visibility =
                            if (listaMutable.isEmpty()) View.VISIBLE else View.GONE
                        listViewGrupos.visibility =
                            if (listaMutable.isEmpty()) View.GONE else View.VISIBLE
                    } else {
                        mostrarSnackbar(respuesta.mensaje, "#F44336")
                        delay(1500)
                        textNoGrupos.visibility = View.VISIBLE
                        listViewGrupos.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, "Error de conexión", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
